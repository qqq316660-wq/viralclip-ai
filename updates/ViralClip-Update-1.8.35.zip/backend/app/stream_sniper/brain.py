"""
AI Brain - Viral Clip Scout Engine
Reads timestamped transcript with (LOUD) and (CHAT) markers to select high-retention moments.
Supports Groq (0.5s ultra-fast), Gemini, OpenRouter, and OpenAI with automatic fallback.
"""
from __future__ import annotations

import json
import logging
import re
import time
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional, Tuple

from . import config, games, roman

logger = logging.getLogger("stream_sniper.brain")

HEAD = """You are an elite viral clip producer and short-form retention strategist for top gaming and streaming creators (YouTube Shorts, Instagram Reels, TikTok).
Below is a timestamped transcript of a video. Each line starts with [seconds]. Lines marked (LOUD)
are where the audio got much louder than usual: screams, hysterical laughter, sudden rage, or peak action. Lines marked (CHAT)
are where the live chat suddenly got much busier.

Stream Title: "{title}"
Channel / Uploader: "{uploader}"

Pick up to {n} moments that work as standalone viral clips:
funny fails, clutch plays, rage freakouts, shocking glitches, hot takes, or crazy conversations with a payoff.
"""

LIVE_NOTE = """
This is a LIVE stream and the transcript is only the last few minutes, ending at {now:.0f} seconds.
If a moment is still unfolding at the very end, leave it out; you will see it again in the next check.
Most checks should return []. Only return a moment you would stop scrolling for.
"""

RULES = """
Core Retention & Packaging Rules:
- The 80/20 Rule: Evaluate every moment primarily on Hook Strength (first 3 seconds). Look for moments that trigger instant curiosity ("Wait, what?!", "No way!", "What did he just say?").
- Each clip is {min_len} to {max_len} seconds. Start on the setup line, not mid-sentence. End right after the payoff/reaction on the last word of a complete sentence.
- PRIORITIZE moments with (LOUD) or (CHAT) markers: screaming, hysterical laughter, rage, gunfights, or shocking fails!
- Do not pick intros, sponsor reads, "like and subscribe", or dead air.
- Skip weak moments. Return [] if nothing qualifies.
- score: 0-100, be honest. Average moments are 50-75; true viral bangers are 85-99.
- hook: 3 to 6 words, ALL CAPS curiosity text overlay (e.g. "HE BROKE HIS CONTROLLER!", "NO WAY HE SURVIVED THIS!", "POLICE CAUGHT HIM IN 4K!", "HE ACTUALLY DID THIS!"). FORBIDDEN to output 1-2 generic words like "HE", "BRO", "WAIT", "LOOK".
- title: authentic Gen-Z internet reaction style under 50 characters ending with 1 emoji (e.g. "bro is actually cooked wtf 💀", "aint no way he survived that lmao 😭", "instant -10000 aura moment 📉"). NEVER include or repeat the streamer's name.
- highlight_words: 3 to 6 punchy single words spoken in the clip for dynamic captions.
- category: one of [funny, fail, clutch, rage, shock, take, story, other].
- reason: one short sentence on why it works.
- Language: English, or natural Roman Hinglish if spoken in Hindi/Urdu (e.g. "YE KYA SCENE HAI!", "bhai pura cooked ho gaya lmao 💀"). Never Devanagari or Urdu script.

Output strictly valid JSON with an array of clip objects:
[{"start": float, "end": float, "score": int, "category": str, "hook": str, "title": str, "suggested_headline": str, "description": str, "hashtags": list[str], "highlight_words": list[str], "reason": str}]
No markdown codeblocks or extra conversation text.
"""

GAME_RULES = """
This stream is {game}. Pick the moments that only mean something with that game in mind:
- A play, a death, a jump scare, a glitch, a discovery, or the streamer reacting to one.
- The hook is what was said at that moment, or, if nothing was said, the name of what happened in
  two or three words ("1 VS 3", "THE SHOT", "HE GOT ME", "CLUTCH"). Never a sentence that needs
  the game explained.
- The title names the game when the clip is about it.
- The hashtags include {tags}.
"""

def build_transcript_text(words: List[Dict], loud_spikes: Optional[List[float]] = None, chat_spikes: Optional[List[float]] = None) -> str:
    """Builds timestamped transcript lines with (LOUD) and (CHAT) markers."""
    if not words:
        return ""
    lines = []
    cur_line = []
    cur_start = words[0]["s"]

    loud_set = set(int(t) for t in (loud_spikes or []))
    chat_set = set(int(t) for t in (chat_spikes or []))

    for w in words:
        cur_line.append(w["w"])
        if len(cur_line) >= 12 or w["w"].endswith((".", "!", "?")):
            sec_int = int(cur_start)
            flags = []
            if any(sec_int + dt in loud_set for dt in (-1, 0, 1)):
                flags.append("(LOUD)")
            if any(sec_int + dt in chat_set for dt in (-1, 0, 1)):
                flags.append("(CHAT)")
            flag_str = (" " + " ".join(flags)) if flags else ""
            lines.append(f"[{cur_start:.1f}s]{flag_str} {' '.join(cur_line)}")
            cur_line = []
            cur_start = w["e"]

    if cur_line:
        lines.append(f"[{cur_start:.1f}s] {' '.join(cur_line)}")

    return "\n".join(lines)


def _call_gemini(sys_prompt: str, user_prompt: str, api_key: str) -> List[Dict]:
    models = ["gemini-flash-lite-latest", "gemini-3-flash-preview", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite-preview", "gemini-flash-latest"]
    payload = {
        "contents": [{"role": "user", "parts": [{"text": sys_prompt + "\n\n" + user_prompt}]}],
        "generationConfig": {"temperature": 0.35, "responseMimeType": "application/json"}
    }
    last_err = None
    for m in models:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={api_key}"
        try:
            req = urllib.request.Request(
                url, data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"},
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=12) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            raw = data["candidates"][0]["content"]["parts"][0]["text"].strip()
            raw = re.sub(r"^```(?:json)?\s*", "", raw)
            raw = re.sub(r"\s*```$", "", raw)
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                for k in ["clips", "moments", "data"]:
                    if k in parsed and isinstance(parsed[k], list):
                        return parsed[k]
                return [parsed] if "start" in parsed else []
            return parsed if isinstance(parsed, list) else []
        except urllib.error.HTTPError as he:
            last_err = he
            if he.code in (404, 429, 503):
                continue
            raise he
        except Exception as e:
            last_err = e
            continue
    if last_err:
        raise last_err
    return []


_DISCOVERED_GEMINI_MODELS = []
_LAST_DISCOVERY_TIME = 0.0
LAST_AI_ERROR = {"provider": None, "code": None, "message": None, "time": 0}

def get_last_ai_error():
    global LAST_AI_ERROR
    return LAST_AI_ERROR

def discover_working_gemini_models(api_key: str, force_refresh: bool = False) -> List[str]:
    """Dynamically queries Google Gemini ListModels API and live-probes candidates to rank working models by latency."""
    global _DISCOVERED_GEMINI_MODELS, _LAST_DISCOVERY_TIME, LAST_AI_ERROR
    now = time.time()
    if not force_refresh and _DISCOVERED_GEMINI_MODELS and (now - _LAST_DISCOVERY_TIME < 600):
        return _DISCOVERED_GEMINI_MODELS

    default_models = ["gemini-flash-lite-latest", "gemini-3-flash-preview", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite-preview", "gemini-flash-latest"]

    models_url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    req = urllib.request.Request(models_url, headers={"User-Agent": "ViralClipAI/1.0"})
    data = {}
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as he:
        err_body = he.read().decode("utf-8", errors="ignore")
        try:
            msg = json.loads(err_body).get("error", {}).get("message") or str(he)
        except Exception:
            msg = str(he)
        if he.code == 429:
            LAST_AI_ERROR = {"provider": "gemini", "code": 429, "message": "Gemini Quota Exceeded (429): Free tier quota limit reached on Google AI Studio. Please generate a new key or use 'Copy Prompt' -> 'Paste JSON'.", "time": time.time()}
        elif he.code in (400, 403):
            LAST_AI_ERROR = {"provider": "gemini", "code": he.code, "message": f"Gemini Key Error ({he.code}): {msg}", "time": time.time()}
        elif he.code == 503:
            LAST_AI_ERROR = {"provider": "gemini", "code": 503, "message": "Gemini Service Unavailable (503): Google's servers are overloaded. Please try again in 1 minute.", "time": time.time()}
        return _DISCOVERED_GEMINI_MODELS or default_models
    except Exception as e:
        logger.warning(f"Failed to query Gemini ListModels: {e}")
        return _DISCOVERED_GEMINI_MODELS or default_models

    candidates = []
    for m in data.get("models", []):
        name = m.get("name", "").replace("models/", "")
        methods = m.get("supportedGenerationMethods", [])
        if "generateContent" in methods and ("flash" in name or "preview" in name) and not ("tts" in name or "image" in name or "robotics" in name):
            candidates.append(name)

    def pref_score(name):
        if "flash-lite-latest" in name: return 0
        if "3-flash" in name: return 1
        if "3.5-flash-lite" in name: return 2
        if "3.1-flash-lite" in name: return 3
        if "flash-latest" in name: return 4
        if "3.8-flash" in name: return 5
        return 10

    candidates.sort(key=pref_score)

    working = []
    # Test top candidate to verify prompt generation without burning quota
    for m in candidates[:2]:
        t0 = time.time()
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={api_key}"
        body = json.dumps({"contents": [{"parts": [{"text": "hi"}]}]}).encode("utf-8")
        r = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"}, method="POST")
        try:
            with urllib.request.urlopen(r, timeout=4) as resp:
                if resp.status == 200:
                    dt = round(time.time() - t0, 2)
                    working.append((m, dt))
                    logger.info(f"Gemini auto-discovery: {m} responsive in {dt}s")
                    break
        except urllib.error.HTTPError as he:
            if he.code == 429:
                LAST_AI_ERROR = {"provider": "gemini", "code": 429, "message": "Gemini Quota Exceeded (429): Free tier quota limit reached on Google AI Studio. Falling back to Groq...", "time": time.time()}
            elif he.code == 503:
                logger.info(f"Gemini {m} experiencing 503 high demand spike, skipped.")
        except Exception:
            pass

    ranked = [w[0] for w in working] + [c for c in candidates if not working or c != working[0][0]] if candidates else default_models
    _DISCOVERED_GEMINI_MODELS = ranked[:6]
    _LAST_DISCOVERY_TIME = time.time()
    return _DISCOVERED_GEMINI_MODELS

_DISCOVERED_GROQ_MODELS = []
_LAST_GROQ_DISCOVERY_TIME = 0.0

def discover_working_groq_models(api_key: str, force_refresh: bool = False) -> List[str]:
    """Dynamically queries Groq ListModels API and live-probes candidates to rank working models by latency."""
    global _DISCOVERED_GROQ_MODELS, _LAST_GROQ_DISCOVERY_TIME
    now = time.time()
    if not force_refresh and _DISCOVERED_GROQ_MODELS and (now - _LAST_GROQ_DISCOVERY_TIME < 600):
        return _DISCOVERED_GROQ_MODELS

    default_models = ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b", "allam-2-7b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant"]

    models_url = "https://api.groq.com/openai/v1/models"
    req = urllib.request.Request(models_url, headers={"Authorization": f"Bearer {api_key}", "User-Agent": "ViralClipAI/1.0"})
    data = {}
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        logger.warning(f"Failed to query Groq models API: {e}")
        return _DISCOVERED_GROQ_MODELS or default_models

    candidates = [
        m.get("id") for m in data.get("data", [])
        if m.get("active", True) and not any(x in (m.get("id") or "").lower() for x in ("whisper", "guard", "orpheus"))
    ]

    def groq_score(m):
        if "120b" in m: return 0
        if "20b" in m: return 1
        if "qwen" in m: return 2
        if "llama" in m: return 3
        if "allam" in m: return 5
        return 10

    candidates.sort(key=groq_score)

    working = []
    for m in candidates[:4]:
        t0 = time.time()
        url = "https://api.groq.com/openai/v1/chat/completions"
        body = json.dumps({"model": m, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 2}).encode("utf-8")
        r = urllib.request.Request(url, data=body, headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"}, method="POST")
        try:
            with urllib.request.urlopen(r, timeout=5) as resp:
                if resp.status == 200:
                    dt = round(time.time() - t0, 2)
                    working.append((m, dt))
                    logger.info(f"Groq auto-discovery: {m} responsive in {dt}s")
        except Exception:
            pass

    working.sort(key=lambda x: x[1])
    ranked = [w[0] for w in working] if working else default_models
    _DISCOVERED_GROQ_MODELS = ranked
    _LAST_GROQ_DISCOVERY_TIME = time.time()
    return ranked

_DISCOVERED_OPENAI_MODELS = []
_LAST_OPENAI_DISCOVERY_TIME = 0.0

def discover_working_openai_models(api_key: str, force_refresh: bool = False) -> List[str]:
    """Dynamically probes OpenAI models to rank working candidates by latency."""
    global _DISCOVERED_OPENAI_MODELS, _LAST_OPENAI_DISCOVERY_TIME
    now = time.time()
    if not force_refresh and _DISCOVERED_OPENAI_MODELS and (now - _LAST_OPENAI_DISCOVERY_TIME < 600):
        return _DISCOVERED_OPENAI_MODELS

    default_models = ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"]
    working = []
    for m in default_models:
        t0 = time.time()
        url = "https://api.openai.com/v1/chat/completions"
        body = json.dumps({"model": m, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 2}).encode("utf-8")
        r = urllib.request.Request(url, data=body, headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"}, method="POST")
        try:
            with urllib.request.urlopen(r, timeout=6) as resp:
                if resp.status == 200:
                    dt = round(time.time() - t0, 2)
                    working.append((m, dt))
                    logger.info(f"OpenAI auto-discovery: {m} responsive in {dt}s")
        except Exception:
            pass

    working.sort(key=lambda x: x[1])
    ranked = [w[0] for w in working] if working else default_models
    _DISCOVERED_OPENAI_MODELS = ranked
    _LAST_OPENAI_DISCOVERY_TIME = time.time()
    return ranked

_DISCOVERED_OPENROUTER_MODELS = []
_LAST_OPENROUTER_DISCOVERY_TIME = 0.0

def discover_working_openrouter_models(api_key: str, force_refresh: bool = False) -> List[str]:
    """Dynamically probes OpenRouter fast models and ranks working candidates."""
    global _DISCOVERED_OPENROUTER_MODELS, _LAST_OPENROUTER_DISCOVERY_TIME
    now = time.time()
    if not force_refresh and _DISCOVERED_OPENROUTER_MODELS and (now - _LAST_OPENROUTER_DISCOVERY_TIME < 600):
        return _DISCOVERED_OPENROUTER_MODELS

    default_models = [
        "meta-llama/llama-3.3-70b-instruct:free",
        "google/gemini-2.0-flash-001",
        "qwen/qwen-2.5-coder-32b-instruct",
        "meta-llama/llama-3.1-8b-instruct:free"
    ]
    working = []
    for m in default_models[:3]:
        t0 = time.time()
        url = "https://openrouter.ai/api/v1/chat/completions"
        body = json.dumps({"model": m, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 2}).encode("utf-8")
        r = urllib.request.Request(url, data=body, headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"}, method="POST")
        try:
            with urllib.request.urlopen(r, timeout=6) as resp:
                if resp.status == 200:
                    dt = round(time.time() - t0, 2)
                    working.append((m, dt))
        except Exception:
            pass

    working.sort(key=lambda x: x[1])
    ranked = [w[0] for w in working] if working else default_models
    _DISCOVERED_OPENROUTER_MODELS = ranked
    _LAST_OPENROUTER_DISCOVERY_TIME = time.time()
    return ranked

def test_api_key(provider: str, key: str) -> Tuple[bool, str]:
    """Tests if the given API key is valid by making a fast lightweight call."""
    key = str(key or "").strip()
    if not key:
        return False, "API key cannot be empty"

    p = provider.lower().strip()
    try:
        if p == "gemini":
            ranked = discover_working_gemini_models(key, force_refresh=True)
            last_err = get_last_ai_error()
            if ranked:
                return True, f"Google Gemini ({ranked[0]}) Verified! Auto-calibrated {len(ranked)} active models."
            elif last_err.get("message") and last_err.get("provider") == "gemini":
                return False, last_err["message"]
            return False, "Failed to verify key with Gemini API. Please check your key or quota at aistudio.google.com."

        elif p == "groq":
            ranked = discover_working_groq_models(key, force_refresh=True)
            if ranked:
                return True, f"Groq ({ranked[0]}) Verified! Auto-calibrated {len(ranked)} active models."
            return False, "Failed to verify key with Groq API. Please check your key at console.groq.com."

        elif p == "openai":
            ranked = discover_working_openai_models(key, force_refresh=True)
            if ranked:
                return True, f"OpenAI ({ranked[0]}) Verified! Auto-calibrated {len(ranked)} active models."
            return False, "Failed to verify key with OpenAI API. Please check your key at platform.openai.com."

        elif p == "openrouter":
            # Test key validity via official OpenRouter key inspection endpoint
            auth_url = "https://openrouter.ai/api/v1/auth/key"
            req = urllib.request.Request(
                auth_url,
                headers={
                    "Authorization": f"Bearer {key}",
                    "User-Agent": "ViralClipAI/1.0"
                },
                method="GET"
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode("utf-8"))
                        key_data = data.get("data", {})
                        label = key_data.get("label") or "Active"
                        ranked = discover_working_openrouter_models(key, force_refresh=True)
                        return True, f"OpenRouter ({ranked[0] if ranked else label}) Verified! Auto-calibrated {len(ranked)} active models."
            except urllib.error.HTTPError as he:
                if he.code in (401, 403):
                    return False, "Invalid OpenRouter API Key or Permission Denied"
                err_body = he.read().decode("utf-8", errors="ignore")
                try:
                    j = json.loads(err_body)
                    return False, j.get("error", {}).get("message") or f"OpenRouter HTTP {he.code}"
                except Exception:
                    return False, f"OpenRouter HTTP {he.code}: {err_body[:100]}"
        else:
            return False, f"Unknown AI provider: {provider}"

    except urllib.error.HTTPError as he:
        err_body = he.read().decode("utf-8", errors="ignore")
        try:
            j = json.loads(err_body)
            msg = j.get("error", {}).get("message") or j.get("message") or f"HTTP {he.code}"
            return False, msg
        except Exception:
            return False, f"HTTP {he.code}: {err_body[:100]}"
    except Exception as e:
        return False, str(e)

    return False, "Failed to verify key with provider."


def generate_chunk_clips_json(prompt: str) -> Optional[str]:
    """Sends chunk prompt to the first working configured AI provider and returns raw response string with seamless fallback."""
    global LAST_AI_ERROR
    keys = config.get_api_keys()
    order = []
    for p in ["gemini", "groq", "openai", "openrouter"]:
        if keys.get(p) and keys[p].strip():
            order.append(p)

    if not order:
        logger.warning("No AI API keys configured for automatic chunk processing.")
        return None

    failed_providers = []

    for provider in order:
        key = keys[provider].strip()
        try:
            if provider == "gemini":
                gemini_models = discover_working_gemini_models(key)
                for m in gemini_models:
                    url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={key}"
                    payload = {
                        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                        "generationConfig": {"temperature": 0.3, "responseMimeType": "application/json"}
                    }
                    try:
                        req = urllib.request.Request(
                            url,
                            data=json.dumps(payload).encode("utf-8"),
                            headers={"Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"},
                            method="POST"
                        )
                        with urllib.request.urlopen(req, timeout=12) as resp:
                            data = json.loads(resp.read().decode("utf-8"))
                        text = data["candidates"][0]["content"]["parts"][0]["text"].strip()
                        if text:
                            logger.info(f"Generated clips JSON via Gemini ({m})")
                            LAST_AI_ERROR = {"provider": None, "code": None, "message": None, "time": 0}
                            return text
                    except urllib.error.HTTPError as he:
                        err_body = he.read().decode("utf-8", errors="ignore")
                        try:
                            msg = json.loads(err_body).get("error", {}).get("message") or str(he)
                        except Exception:
                            msg = str(he)
                        if he.code == 429:
                            LAST_AI_ERROR = {"provider": "gemini", "code": 429, "message": "Gemini Quota Exceeded (429): Free tier quota reached. Falling back to next AI...", "time": time.time()}
                        elif he.code in (400, 403):
                            LAST_AI_ERROR = {"provider": "gemini", "code": he.code, "message": f"Gemini Error ({he.code}): {msg}", "time": time.time()}
                        elif he.code == 503:
                            LAST_AI_ERROR = {"provider": "gemini", "code": 503, "message": "Gemini Service Unavailable (503): Falling back to next AI...", "time": time.time()}
                        logger.warning(f"Gemini model {m} HTTP {he.code}: {he}")
                        continue
                    except Exception as ge:
                        logger.warning(f"Gemini model {m} error: {ge}")
                        continue
                failed_providers.append("Gemini (rate limit/quota)")

            elif provider == "groq":
                url = "https://api.groq.com/openai/v1/chat/completions"
                groq_models = discover_working_groq_models(key)

                # Groq has a 7,000-8,000 TPM limit on free tier. If prompt > 13,000 chars, split transcript into 2 parts
                prompts_to_run = [prompt]
                if len(prompt) > 13000:
                    lines = prompt.split("\n")
                    t_start = 0
                    for i, l in enumerate(lines):
                        if "<transcript>" in l or (len(l) > 6 and l[0] == "[" and ("s]" in l[:10] or ":" in l[:10])):
                            t_start = i
                            break
                    header = "\n".join(lines[:t_start])
                    t_lines = lines[t_start:]
                    mid = len(t_lines) // 2
                    p1 = header + "\n" + "\n".join(t_lines[:mid]) + "\n\n(Extract top viral clips from Part 1)"
                    p2 = header + "\n" + "\n".join(t_lines[mid:]) + "\n\n(Extract top viral clips from Part 2)"
                    prompts_to_run = [p1, p2]

                all_clips = []
                for p_chunk in prompts_to_run:
                    for model in groq_models:
                        payload = {
                            "model": model,
                            "messages": [
                                {"role": "system", "content": "You are a professional viral short-form video scout. Always output strictly a valid JSON array or object with start, end, hook, score, title, description."},
                                {"role": "user", "content": p_chunk}
                            ],
                            "temperature": 0.3,
                            "response_format": {"type": "json_object"}
                        }
                        try:
                            req = urllib.request.Request(
                                url,
                                data=json.dumps(payload).encode("utf-8"),
                                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"},
                                method="POST"
                            )
                            with urllib.request.urlopen(req, timeout=30) as resp:
                                data = json.loads(resp.read().decode("utf-8"))
                            text = data["choices"][0]["message"]["content"].strip()
                            if text:
                                try:
                                    from .session import parse_clips_json
                                except Exception:
                                    try:
                                        from app.stream_sniper.session import parse_clips_json
                                    except Exception:
                                        from backend.app.stream_sniper.session import parse_clips_json
                                parsed = parse_clips_json(text)
                                if parsed:
                                    all_clips.extend(parsed)
                                    logger.info(f"Generated {len(parsed)} clips via Groq ({model})")
                                    break
                        except urllib.error.HTTPError as he:
                            logger.warning(f"Groq model {model} HTTP {he.code}: {he}")
                            continue
                        except Exception as ge:
                            logger.warning(f"Groq model {model} error: {ge}")
                            continue

                if all_clips:
                    LAST_AI_ERROR = {"provider": None, "code": None, "message": None, "time": 0}
                    return json.dumps(all_clips)

                failed_providers.append("Groq (models busy/quota)")

            elif provider == "openai":
                url = "https://api.openai.com/v1/chat/completions"
                payload = {
                    "model": "gpt-4o-mini",
                    "messages": [
                        {"role": "system", "content": "You are a professional viral short-form video scout. Always output strictly a valid JSON array."},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0.3,
                    "response_format": {"type": "json_object"}
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode("utf-8"),
                    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"},
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=35) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                text = data["choices"][0]["message"]["content"].strip()
                if text:
                    logger.info("Generated clips JSON via OpenAI (gpt-4o-mini)")
                    LAST_AI_ERROR = {"provider": None, "code": None, "message": None, "time": 0}
                    return text

            elif provider == "openrouter":
                url = "https://openrouter.ai/api/v1/chat/completions"
                for model in [
                    "meta-llama/llama-3.3-70b-instruct",
                    "google/gemini-2.0-flash-001",
                    "google/gemini-flash-1.5",
                    "meta-llama/llama-3.1-8b-instruct",
                    "qwen/qwen-2.5-coder-32b-instruct",
                    "meta-llama/llama-3.3-70b-instruct:free",
                    "meta-llama/llama-3.1-8b-instruct:free"
                ]:
                    payload = {
                        "model": model,
                        "messages": [
                            {"role": "system", "content": "You are a professional viral short-form video scout. Always output strictly a valid JSON array."},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": 0.3
                    }
                    try:
                        req = urllib.request.Request(
                            url,
                            data=json.dumps(payload).encode("utf-8"),
                            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json", "User-Agent": "ViralClipAI/1.0"},
                            method="POST"
                        )
                        with urllib.request.urlopen(req, timeout=35) as resp:
                            data = json.loads(resp.read().decode("utf-8"))
                        text = data["choices"][0]["message"]["content"].strip()
                        if text:
                            logger.info(f"Generated clips JSON via OpenRouter ({model})")
                            LAST_AI_ERROR = {"provider": None, "code": None, "message": None, "time": 0}
                            return text
                    except urllib.error.HTTPError as he:
                        if he.code in (404, 400):
                            continue
                        raise he

        except Exception as e:
            logger.warning(f"Error querying provider {provider}: {e}")
            failed_providers.append(f"{provider.capitalize()} ({e})")
            continue

    if failed_providers:
        LAST_AI_ERROR = {
            "provider": "multi",
            "code": 429,
            "message": f"AI providers busy/quota: {', '.join(failed_providers)}. Use 'Copy Prompt' to paste into ChatGPT, or generate a new key.",
            "time": time.time()
        }

    return None

    return None


def _call_openai_compatible(endpoint: str, sys_prompt: str, user_prompt: str, api_key: str, models: List[str]) -> List[Dict]:
    last_err = None
    for model_name in models:
        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": 0.35,
            "response_format": {"type": "json_object"}
        }
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        try:
            req = urllib.request.Request(endpoint, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            content = data["choices"][0]["message"]["content"].strip()
            parsed = json.loads(content)
            if isinstance(parsed, dict):
                for k in ["clips", "moments", "data", "results"]:
                    if k in parsed and isinstance(parsed[k], list):
                        return parsed[k]
                if "start" in parsed and "end" in parsed:
                    return [parsed]
                return []
            return parsed if isinstance(parsed, list) else []
        except urllib.error.HTTPError as he:
            last_err = he
            if he.code in (404, 400):
                continue
            raise he
        except Exception as e:
            last_err = e
            raise e
    if last_err:
        raise last_err
    return []


def select_clips(
    transcript: str,
    title: str,
    uploader: str,
    game: str,
    api_keys: Dict[str, str],
    is_live: bool = False,
    now_sec: float = 0.0,
    min_len: int = 20,
    max_len: int = 55,
    min_score: int = 70,
    n_clips: int = 6,
    primary_ai: str = "groq"
) -> Tuple[List[Dict], str, List[str]]:
    """
    AI Brain Selection with Multi-AI Fallback.
    Returns: (clips, used_provider, logs)
    """
    logs = []
    game_name, game_tags = games.detect(title, game)
    game_part = ""
    if game_name:
        game_part = GAME_RULES.format(game=game_name, tags=", ".join(game_tags[:5]))

    live_part = LIVE_NOTE.format(now=now_sec) if is_live else ""
    sys_prompt = HEAD.format(title=title, uploader=uploader, n=n_clips) + game_part + live_part + RULES.format(min_len=min_len, max_len=max_len)
    user_prompt = f"<transcript>\n{transcript}\n</transcript>"

    order = [primary_ai]
    for p in ["groq", "gemini", "openrouter", "openai"]:
        if p not in order and api_keys.get(p) and api_keys[p].strip():
            order.append(p)

    for provider in order:
        key = (api_keys.get(provider) or "").strip()
        if not key:
            continue
        logs.append(f"Brain evaluating with {provider.upper()}...")
        try:
            raw_clips = []
            if provider == "groq":
                groq_models = discover_working_groq_models(key)
                raw_clips = _call_openai_compatible(
                    "https://api.groq.com/openai/v1/chat/completions",
                    sys_prompt, user_prompt, key,
                    groq_models
                )
            elif provider == "gemini":
                raw_clips = _call_gemini(sys_prompt, user_prompt, key)
            elif provider == "openrouter":
                raw_clips = _call_openai_compatible(
                    "https://openrouter.ai/api/v1/chat/completions",
                    sys_prompt, user_prompt, key,
                    ["nvidia/nemotron-3.5-lightning:free", "inclusionai/ling-3.2-flash:free", "particle-ai/particle-1:free"]
                )
            elif provider == "openai":
                raw_clips = _call_openai_compatible(
                    "https://api.openai.com/v1/chat/completions",
                    sys_prompt, user_prompt, key,
                    ["gpt-4o-mini", "gpt-3.5-turbo"]
                )

            valid = []
            for c in raw_clips:
                if not isinstance(c, dict):
                    continue
                start = float(c.get("start", 0))
                end = float(c.get("end", 0))
                score = int(c.get("score", 70))
                dur = end - start
                if dur >= min_len - 3 and dur <= max_len + 5 and score >= min_score:
                    c["start"] = round(start, 2)
                    c["end"] = round(end, 2)
                    c["score"] = score
                    c["hook"] = str(c.get("hook") or "VIRAL MOMENT").upper()[:40]
                    c["title"] = str(c.get("title") or title)[:70]
                    c["description"] = str(c.get("description") or "")[:200]
                    c["hashtags"] = c.get("hashtags") or (game_tags[:5] if game_tags else ["gaming", "shorts"])
                    c["highlight_words"] = c.get("highlight_words") or []
                    c["category"] = str(c.get("category") or "other").lower()
                    c["reason"] = str(c.get("reason") or "Peak engagement moment")[:200]
                    valid.append(c)

            if valid:
                logs.append(f"{provider.upper()} returned {len(valid)} viral moments")
                return valid, provider, logs

        except Exception as e:
            logs.append(f"{provider.upper()} error: {str(e)[:100]}. Auto-fallback triggered.")
            logger.warning(f"Brain provider {provider} failed: {e}")

    # Heuristic fallback from transcript lines
    logs.append("Triggering smart heuristic transcript fallback...")
    fallback_clips = _heuristic_clips(transcript, title, min_len, max_len, game_tags)
    return fallback_clips, "heuristic_pulse", logs


def _heuristic_clips(transcript: str, title: str, min_len: int, max_len: int, game_tags: List[str]) -> List[Dict]:
    lines = []
    for line in transcript.split("\n"):
        m = re.match(r"\[([\d\.]+)s\](?:\s*\((?:LOUD|CHAT)\))*\s*(.*)", line.strip())
        if m:
            lines.append((float(m.group(1)), m.group(2).strip(), "(LOUD)" in line or "(CHAT)" in line))
    if not lines:
        return []
    clips = []
    i = 0
    while i < len(lines):
        start_t, text_acc, is_hot = lines[i]
        curr_text = [text_acc]
        end_t = start_t + 10.0
        j = i + 1
        while j < len(lines) and (lines[j][0] - start_t) <= max_len:
            end_t = lines[j][0] + 5.0
            curr_text.append(lines[j][1])
            if lines[j][2]:
                is_hot = True
            j += 1
        dur = end_t - start_t
        if dur >= min_len:
            words = [w for w in " ".join(curr_text).split() if len(w) > 3]
            hook = " ".join(words[:4]).upper() if words else "STREAM HIGHLIGHT"
            clips.append({
                "start": round(start_t, 2),
                "end": round(end_t, 2),
                "score": 90 if is_hot else 80,
                "hook": hook[:35],
                "title": f"{title[:40]} Highlight #{len(clips)+1}",
                "description": f"Highlight moment from {title}",
                "hashtags": game_tags[:5] if game_tags else ["gaming", "shorts"],
                "highlight_words": words[:4],
                "category": "clutch" if is_hot else "funny",
                "reason": "High volume energy & viewer reaction spike"
            })
            i = j
        else:
            i += 1
        if len(clips) >= 10:
            break
    return clips
