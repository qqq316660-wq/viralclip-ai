"""
Applies Apple iOS 3D Soft Gradient theme to StreamSniper.jsx:
1. Replaces harsh neon cyan (#00F0FF) with Apple System Indigo/Blue (#0A84FF) / Apple Sky (#5AC8FA)
2. Replaces harsh red (#ff4444) with Apple Velvet Coral/Rose (#FF375F)
3. Upgrades buttons to soft 3D gradients with top rim highlights and rounded geometry
4. Upgrades cards to iOS dark materials with subtle ambient shadows
"""
import re
from pathlib import Path

path = Path("frontend/src/components/StreamSniper.jsx")
text = path.read_text(encoding="utf-8")

# 1. Update Deep VOD Scanner button
text = text.replace(
    """          {/* Deep VOD Scanner (Active) */}
          <button
            type="button"
            onClick={() => { setMode('vod'); setGalleryFilter('vod'); }}
            style={{
              padding: '9px 24px',
              borderRadius: '24px',
              border: 'none',
              background: '#ff4444',
              color: '#ffffff',
              fontWeight: 800,
              fontSize: '14px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              boxShadow: '0 4px 15px rgba(255, 68, 68, 0.35)',
              transition: 'all 0.2s'
            }}
          >""",
    """          {/* Deep VOD Scanner (Active) */}
          <button
            type="button"
            onClick={() => { setMode('vod'); setGalleryFilter('vod'); }}
            style={{
              padding: '9px 22px',
              borderRadius: '24px',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              background: 'linear-gradient(180deg, #1f8eff 0%, #0066cc 100%)',
              color: '#ffffff',
              fontWeight: 700,
              fontSize: '13px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              boxShadow: '0 4px 16px rgba(10, 132, 255, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.35)',
              transition: 'all 0.2s'
            }}
          >"""
)

# 2. Update Analyze & Chunk Stream button
text = text.replace(
    """              <button
                onClick={handleInitVODClick}
                disabled={isFetchingFrame || isInitializingVod || !streamUrl.trim()}
                style={{
                  background: 'linear-gradient(135deg, #ff4444, #ff2222)',
                  border: 'none',
                  color: '#fff',
                  padding: '0 28px',
                  borderRadius: '10px',
                  fontWeight: 800,
                  cursor: streamUrl.trim() && !isFetchingFrame && !isInitializingVod ? 'pointer' : 'not-allowed',
                  opacity: streamUrl.trim() ? 1 : 0.6,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  boxShadow: '0 4px 15px rgba(255,68,68,0.3)'
                }}
              >""",
    """              <button
                onClick={handleInitVODClick}
                disabled={isFetchingFrame || isInitializingVod || !streamUrl.trim()}
                style={{
                  background: 'linear-gradient(180deg, #1f8eff 0%, #0066cc 100%)',
                  border: '1px solid rgba(255, 255, 255, 0.25)',
                  color: '#fff',
                  padding: '0 28px',
                  borderRadius: '12px',
                  fontWeight: 700,
                  fontSize: '14px',
                  cursor: streamUrl.trim() && !isFetchingFrame && !isInitializingVod ? 'pointer' : 'not-allowed',
                  opacity: streamUrl.trim() ? 1 : 0.6,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  boxShadow: '0 4px 16px rgba(10, 132, 255, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.35)'
                }}
              >"""
)

# 3. Stream info header buttons
# Game badge
text = text.replace(
    """                  <span style={{ background: '#00F0FF', color: '#000', padding: '2px 8px', borderRadius: '6px', fontSize: '11px', fontWeight: 900 }}>
                    {vodStatus.game || 'Gaming'}
                  </span>""",
    """                  <span style={{ background: 'linear-gradient(135deg, rgba(10, 132, 255, 0.2) 0%, rgba(94, 92, 230, 0.2) 100%)', border: '1px solid rgba(10, 132, 255, 0.4)', color: '#5ac8fa', padding: '3px 10px', borderRadius: '8px', fontSize: '11px', fontWeight: 700 }}>
                    {vodStatus.game || 'Gaming'}
                  </span>"""
)

# AI Auto-mode button in header
text = text.replace(
    """                  style={{
                    background: aiMode === 'auto' ? 'rgba(0, 240, 255, 0.14)' : 'rgba(255, 187, 51, 0.12)',
                    border: aiMode === 'auto' ? '1px solid #00F0FF' : '1px solid #ffbb33',
                    color: aiMode === 'auto' ? '#00F0FF' : '#ffbb33',
                    padding: '8px 14px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 800,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}""",
    """                  style={{
                    background: aiMode === 'auto'
                      ? 'linear-gradient(180deg, rgba(10, 132, 255, 0.2) 0%, rgba(10, 132, 255, 0.08) 100%)'
                      : 'linear-gradient(180deg, rgba(255, 159, 10, 0.15) 0%, rgba(255, 159, 10, 0.05) 100%)',
                    border: aiMode === 'auto' ? '1px solid rgba(10, 132, 255, 0.45)' : '1px solid rgba(255, 159, 10, 0.35)',
                    color: aiMode === 'auto' ? '#5ac8fa' : '#ff9f0a',
                    padding: '8px 14px',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    boxShadow: aiMode === 'auto' ? '0 2px 10px rgba(10, 132, 255, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.12)' : 'none'
                  }}"""
)

# Reframe Layout button in header
text = text.replace(
    """                  style={{
                    background: 'rgba(255, 68, 68, 0.12)',
                    border: '1px solid rgba(255, 68, 68, 0.4)',
                    color: '#ff6666',
                    padding: '8px 14px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 800,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}""",
    """                  style={{
                    background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.07) 0%, rgba(255, 255, 255, 0.02) 100%)',
                    border: '1px solid rgba(255, 255, 255, 0.14)',
                    color: '#e4e7eb',
                    padding: '8px 14px',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                  }}"""
)

# Stream Settings button in header
text = text.replace(
    """                  style={{ background: '#262626', border: '1px solid #444', color: '#eee', padding: '8px 14px', borderRadius: '8px', fontSize: '12px', fontWeight: 800, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}""",
    """                  style={{
                    background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.07) 0%, rgba(255, 255, 255, 0.02) 100%)',
                    border: '1px solid rgba(255, 255, 255, 0.14)',
                    color: '#e4e7eb',
                    padding: '8px 14px',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                  }}"""
)

# Clear / New Stream button in header
text = text.replace(
    """                  style={{
                    background: 'rgba(255, 68, 68, 0.08)',
                    border: '1px solid rgba(255, 68, 68, 0.35)',
                    color: '#ff6666',
                    padding: '8px 14px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 800,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255, 68, 68, 0.2)'; e.currentTarget.style.color = '#fff'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255, 68, 68, 0.08)'; e.currentTarget.style.color = '#ff6666'; }}""",
    """                  style={{
                    background: 'linear-gradient(180deg, rgba(255, 55, 95, 0.1) 0%, rgba(255, 55, 95, 0.03) 100%)',
                    border: '1px solid rgba(255, 55, 95, 0.25)',
                    color: '#ff6482',
                    padding: '8px 14px',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    boxShadow: '0 2px 8px rgba(255, 55, 95, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.06)'
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255, 55, 95, 0.18)'; e.currentTarget.style.color = '#fff'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255, 55, 95, 0.08)'; e.currentTarget.style.color = '#ff6482'; }}"""
)

# 4. Chunk Card background styling
text = text.replace(
    """                      background: isSelected ? 'rgba(255, 187, 51, 0.08)' : isProcessing ? 'rgba(0, 240, 255, 0.04)' : (isQueued || isQueuedRender) ? 'rgba(255, 145, 0, 0.06)' : isDone ? 'rgba(0, 230, 118, 0.04)' : '#141414',
                      border: isSelected ? '1px solid #ffbb33' : isProcessing ? '1px solid #00F0FF' : isQueued ? '1px solid #ff9100' : isQueuedRender ? '1px solid #ffbb33' : isDone ? '1px solid rgba(0, 230, 118, 0.4)' : hasPromptReady ? '1px solid rgba(0, 240, 255, 0.4)' : isError ? '1px solid #ff4444' : '1px solid #282828',
                      borderRadius: '12px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      position: 'relative',
                      boxShadow: isProcessing ? '0 0 15px rgba(0, 240, 255, 0.15)' : (isQueued || isQueuedRender) ? '0 0 12px rgba(255, 145, 0, 0.12)' : 'none',
                      transition: 'all 0.3s ease'""",
    """                      background: isSelected
                        ? 'linear-gradient(180deg, rgba(255, 159, 10, 0.08) 0%, rgba(20, 22, 32, 0.95) 100%)'
                        : isProcessing
                        ? 'linear-gradient(180deg, rgba(10, 132, 255, 0.1) 0%, rgba(18, 22, 36, 0.95) 100%)'
                        : isDone
                        ? 'linear-gradient(180deg, rgba(48, 209, 88, 0.08) 0%, rgba(18, 26, 22, 0.95) 100%)'
                        : hasPromptReady
                        ? 'linear-gradient(180deg, rgba(10, 132, 255, 0.05) 0%, rgba(20, 22, 32, 0.95) 100%)'
                        : isError
                        ? 'linear-gradient(180deg, rgba(255, 55, 95, 0.08) 0%, rgba(24, 18, 22, 0.95) 100%)'
                        : 'linear-gradient(180deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.005) 100%), #141620',
                      border: isSelected
                        ? '1px solid rgba(255, 159, 10, 0.5)'
                        : isProcessing
                        ? '1px solid rgba(10, 132, 255, 0.55)'
                        : isDone
                        ? '1px solid rgba(48, 209, 88, 0.35)'
                        : hasPromptReady
                        ? '1px solid rgba(10, 132, 255, 0.35)'
                        : isError
                        ? '1px solid rgba(255, 55, 95, 0.45)'
                        : '1px solid rgba(255, 255, 255, 0.08)',
                      borderRadius: '14px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      position: 'relative',
                      boxShadow: isProcessing
                        ? '0 8px 24px rgba(10, 132, 255, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                        : isDone
                        ? '0 6px 20px rgba(48, 209, 88, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.08)'
                        : hasPromptReady
                        ? '0 4px 16px rgba(10, 132, 255, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.06)'
                        : '0 4px 16px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)',
                      transition: 'all 0.3s ease'"""
)

# Chunk ID badge
text = text.replace(
    """                            <span style={{ fontSize: '10px', color: '#00F0FF', fontFamily: 'monospace', background: 'rgba(0, 240, 255, 0.08)', padding: '1px 5px', borderRadius: '4px' }}>
                              ID: {chunk.chunk_id || `c${chunk.index + 1}`}
                            </span>""",
    """                            <span style={{ fontSize: '10px', color: '#8ab4f8', fontFamily: 'monospace', background: 'rgba(138, 180, 248, 0.12)', border: '1px solid rgba(138, 180, 248, 0.22)', padding: '1px 6px', borderRadius: '6px' }}>
                              ID: {chunk.chunk_id || `c${chunk.index + 1}`}
                            </span>"""
)

# Transcribe 30m Chunk button (idle)
text = text.replace(
    """                          <button
                            onClick={() => handleTranscribeClick(chunk.index)}
                            style={{
                              background: '#222',
                              border: '1px solid #333',
                              color: '#fff',
                              padding: '8px 12px',
                              borderRadius: '8px',
                              fontSize: '12px',
                              fontWeight: 800,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '6px'
                            }}
                          >
                            <Lightning size={14} color="#00F0FF" />
                            <span>Transcribe {chunkMinutes}m Chunk</span>
                          </button>""",
    """                          <button
                            onClick={() => handleTranscribeClick(chunk.index)}
                            style={{
                              background: 'linear-gradient(180deg, #1f8eff 0%, #0066cc 100%)',
                              border: '1px solid rgba(255, 255, 255, 0.25)',
                              color: '#fff',
                              padding: '9px 12px',
                              borderRadius: '10px',
                              fontSize: '12px',
                              fontWeight: 700,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '6px',
                              boxShadow: '0 4px 14px rgba(10, 132, 255, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.35)'
                            }}
                          >
                            <Lightning size={14} color="#fff" weight="fill" />
                            <span>Transcribe {chunkMinutes}m Chunk</span>
                          </button>"""
)

# AI Brain, Copy Prompt, Paste JSON buttons
text = text.replace(
    """                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button
                            type="button"
                            onClick={() => handleAiBrainClick(chunk.index)}
                            title="Run AI Brain (Auto-detects viral moments with verified API key)"
                            style={{
                              flex: 1,
                              background: 'linear-gradient(135deg, rgba(0, 240, 255, 0.25), rgba(0, 230, 118, 0.25))',
                              border: '1px solid #00F0FF',
                              color: '#00F0FF',
                              padding: '8px 4px',
                              borderRadius: '8px',
                              fontSize: '11px',
                              fontWeight: 800,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '4px',
                              whiteSpace: 'nowrap'
                            }}
                          >
                            <Lightning size={13} weight="fill" color="#00F0FF" />
                            <span>AI Brain</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenPrompt(chunk.index)}
                            style={{
                              flex: 1,
                              background: 'rgba(0, 240, 255, 0.1)',
                              border: '1px solid rgba(0, 240, 255, 0.4)',
                              color: '#00F0FF',
                              padding: '8px 4px',
                              borderRadius: '8px',
                              fontSize: '11px',
                              fontWeight: 800,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '4px',
                              whiteSpace: 'nowrap'
                            }}
                          >
                            <Copy size={13} />
                            <span>Copy Prompt</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setJsonPasteModalChunk(chunk.index);
                              setPastedJsonText('');
                            }}
                            style={{
                              flex: 1,
                              background: 'linear-gradient(135deg, #ff4444, #ff1744)',
                              border: 'none',
                              color: '#fff',
                              padding: '8px 4px',
                              borderRadius: '8px',
                              fontSize: '11px',
                              fontWeight: 800,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '4px',
                              whiteSpace: 'nowrap'
                            }}
                          >
                            <Sparkle size={13} weight="fill" />
                            <span>Paste JSON</span>
                          </button>
                        </div>""",
    """                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button
                            type="button"
                            onClick={() => handleAiBrainClick(chunk.index)}
                            title="Run AI Brain (Auto-detects viral moments with verified API key)"
                            style={{
                              flex: 1,
                              background: 'linear-gradient(180deg, #1f8eff 0%, #0066cc 100%)',
                              border: '1px solid rgba(255, 255, 255, 0.25)',
                              color: '#ffffff',
                              padding: '8px 4px',
                              borderRadius: '9px',
                              fontSize: '11px',
                              fontWeight: 700,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '4px',
                              whiteSpace: 'nowrap',
                              boxShadow: '0 4px 12px rgba(10, 132, 255, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.35)'
                            }}
                          >
                            <Lightning size={13} weight="fill" color="#ffffff" />
                            <span>AI Brain</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenPrompt(chunk.index)}
                            style={{
                              flex: 1,
                              background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0.02) 100%)',
                              border: '1px solid rgba(255, 255, 255, 0.14)',
                              color: '#e4e7eb',
                              padding: '8px 4px',
                              borderRadius: '9px',
                              fontSize: '11px',
                              fontWeight: 700,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '4px',
                              whiteSpace: 'nowrap',
                              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                            }}
                          >
                            <Copy size={13} />
                            <span>Copy Prompt</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setJsonPasteModalChunk(chunk.index);
                              setPastedJsonText('');
                            }}
                            style={{
                              flex: 1,
                              background: 'linear-gradient(180deg, #ff4569 0%, #d62246 100%)',
                              border: '1px solid rgba(255, 255, 255, 0.2)',
                              color: '#fff',
                              padding: '8px 4px',
                              borderRadius: '9px',
                              fontSize: '11px',
                              fontWeight: 700,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '4px',
                              whiteSpace: 'nowrap',
                              boxShadow: '0 4px 12px rgba(255, 69, 105, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.25)'
                            }}
                          >
                            <Sparkle size={13} weight="fill" />
                            <span>Paste JSON</span>
                          </button>
                        </div>"""
)

# AI API Key Modal Buttons
text = text.replace(
    """                <button
                  type="button"
                  onClick={() => handleTestKey(selectedKeyProvider)}
                  disabled={testingProvider === selectedKeyProvider || (!keyInputs[selectedKeyProvider]?.trim() && !keysInfo[selectedKeyProvider])}
                  style={{
                    flex: 1,
                    background: '#222',
                    border: '1px solid #383838',
                    color: '#fff',
                    padding: '10px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: testingProvider === selectedKeyProvider ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px'
                  }}
                >
                  {testingProvider === selectedKeyProvider ? <CircleNotch size={14} className="animate-spin" /> : <span>🧪</span>}
                  <span>{testingProvider === selectedKeyProvider ? 'Testing...' : 'Test Key (Verify OK)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleSaveKeys(true);
                    if (pendingTranscribeChunk !== null) {
                      handleProcessChunk(pendingTranscribeChunk);
                      setPendingTranscribeChunk(null);
                    }
                  }}
                  disabled={isSavingKey || (!keyInputs[selectedKeyProvider]?.trim() && !keysInfo[selectedKeyProvider])}
                  style={{
                    flex: 2,
                    background: 'linear-gradient(135deg, #00F0FF 0%, #00a8ff 100%)',
                    border: 'none',
                    color: '#000',
                    padding: '10px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 800,
                    cursor: isSavingKey ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px'
                  }}
                >
                  {isSavingKey ? <CircleNotch size={14} className="animate-spin" /> : <Check size={14} weight="bold" />}
                  <span>Save & Turn ON Automatic AI</span>
                </button>""",
    """                <button
                  type="button"
                  onClick={() => handleTestKey(selectedKeyProvider)}
                  disabled={testingProvider === selectedKeyProvider || (!keyInputs[selectedKeyProvider]?.trim() && !keysInfo[selectedKeyProvider])}
                  style={{
                    flex: 1,
                    background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0.02) 100%)',
                    border: '1px solid rgba(255, 255, 255, 0.15)',
                    color: '#fff',
                    padding: '11px',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: testingProvider === selectedKeyProvider ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.12)'
                  }}
                >
                  {testingProvider === selectedKeyProvider ? <CircleNotch size={14} className="animate-spin" /> : <span>🧪</span>}
                  <span>{testingProvider === selectedKeyProvider ? 'Testing...' : 'Test Key (Verify OK)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleSaveKeys(true);
                    if (pendingTranscribeChunk !== null) {
                      handleProcessChunk(pendingTranscribeChunk);
                      setPendingTranscribeChunk(null);
                    }
                  }}
                  disabled={isSavingKey || (!keyInputs[selectedKeyProvider]?.trim() && !keysInfo[selectedKeyProvider])}
                  style={{
                    flex: 2,
                    background: 'linear-gradient(180deg, #1f8eff 0%, #0066cc 100%)',
                    border: '1px solid rgba(255, 255, 255, 0.25)',
                    color: '#ffffff',
                    padding: '11px',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: isSavingKey ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px',
                    boxShadow: '0 4px 16px rgba(10, 132, 255, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.35)'
                  }}
                >
                  {isSavingKey ? <CircleNotch size={14} className="animate-spin" /> : <Check size={14} weight="bold" />}
                  <span>Save & Turn ON Automatic AI</span>
                </button>"""
)

# AI Modal Title & Badge
text = text.replace(
    """                  <Key size={22} color="#00F0FF" weight="fill" />
                  <h3 style={{ fontSize: '18px', fontWeight: 800, margin: 0 }}>Configure AI API Key</h3>
                  <span style={{ fontSize: '10px', background: 'rgba(0,240,255,0.15)', color: '#00F0FF', padding: '2px 8px', borderRadius: '6px', fontWeight: 800 }}>
                    1-Click Auto Mode
                  </span>""",
    """                  <Key size={22} color="#0A84FF" weight="fill" />
                  <h3 style={{ fontSize: '18px', fontWeight: 700, margin: 0, color: '#f5f5f7' }}>Configure AI API Key</h3>
                  <span style={{ fontSize: '10px', background: 'rgba(10, 132, 255, 0.15)', border: '1px solid rgba(10, 132, 255, 0.3)', color: '#5ac8fa', padding: '2px 8px', borderRadius: '6px', fontWeight: 700 }}>
                    1-Click Auto Mode
                  </span>"""
)

# Replace remaining harsh #00F0FF with soft Apple Sky/Blue #5AC8FA or #0A84FF where appropriate
# in AI Modal tabs:
text = text.replace(
    "{ id: 'gemini', label: 'Google Gemini', desc: 'Free & Smart', badge: 'Recommended', color: '#00F0FF', has: keysInfo.gemini }",
    "{ id: 'gemini', label: 'Google Gemini', desc: 'Free & Smart', badge: 'Recommended', color: '#0A84FF', has: keysInfo.gemini }"
)

path.write_text(text, encoding="utf-8")
print("Theme applied successfully to StreamSniper.jsx!")
