"""
ASR Transcription Engine - Dual Parakeet / Faster-Whisper with PeakCut Architecture.
Transcribes audio into word-level timestamps [{'w': word, 's': start_sec, 'e': end_sec}].
Defaults to Faster-Whisper (local bundled) or Sherpa-ONNX Parakeet (if installed).
"""
from __future__ import annotations

import os
import subprocess
import threading
import wave
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from . import config

_lock = threading.Lock()
_recognizer = None


def is_model_ready() -> bool:
    """Returns True only if sherpa_onnx is installed and Parakeet model files exist."""
    try:
        import sherpa_onnx  # noqa: F401
    except ImportError:
        return False

    if not config.MODEL_DIR.is_dir():
        return False
    enc = list(config.MODEL_DIR.glob("encoder*.onnx"))
    tokens = config.MODEL_DIR / "tokens.txt"
    return bool(enc and tokens.is_file())


def get_recognizer():
    global _recognizer
    if _recognizer is not None:
        return _recognizer

    with _lock:
        if _recognizer is not None:
            return _recognizer

        import sherpa_onnx

        encoder_file = next(config.MODEL_DIR.glob("encoder*.onnx"), None)
        decoder_file = next(config.MODEL_DIR.glob("decoder*.onnx"), None)
        joiner_file = next(config.MODEL_DIR.glob("joiner*.onnx"), None)
        tokens_file = config.MODEL_DIR / "tokens.txt"

        if not all([encoder_file, decoder_file, joiner_file, tokens_file.is_file()]):
            raise RuntimeError(f"Missing model files in {config.MODEL_DIR}")

        cpus = os.cpu_count() or 4
        threads = max(2, min(6, cpus - 1))

        _recognizer = sherpa_onnx.OfflineRecognizer.from_transducer(
            encoder=str(encoder_file),
            decoder=str(decoder_file),
            joiner=str(joiner_file),
            tokens=str(tokens_file),
            num_threads=threads,
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            model_type="nemo_transducer",
        )
        return _recognizer


def _split_quiet_chunks(audio: np.ndarray, lo: float = 12.0, hi: float = 24.0, sr: int = 16000):
    """Split at quiet moments between lo and hi seconds so words are not cut in half."""
    hop = 800  # 50 ms frames
    n = len(audio)
    frames = n // hop
    if frames == 0:
        if n > 0:
            yield 0, n
        return
    x = audio[: frames * hop].reshape(frames, hop).astype(np.float32)
    rms = np.sqrt((x ** 2).mean(axis=1))
    pos = 0
    while pos < n:
        if n - pos <= hi * sr:
            yield pos, n
            return
        a = (pos + int(lo * sr)) // hop
        b = (pos + int(hi * sr)) // hop
        if a >= frames or a >= b:
            yield pos, min(n, pos + int(hi * sr))
            pos += int(hi * sr)
            continue
        cut = (a + int(np.argmin(rms[a:b]))) * hop + hop // 2
        yield pos, cut
        pos = cut


def _tokens_to_words(tokens: List[str], timestamps: List[float], offset_sec: float = 0.0) -> List[Dict]:
    """Converts SentencePiece tokens to [{'w': word, 's': start_sec, 'e': end_sec}]"""
    out = []
    cur, gap = None, False
    for tok, t in zip(tokens, timestamps):
        new_word = tok.startswith((" ", "▁")) or gap
        piece = tok.replace("▁", " ").strip()
        if not piece:
            gap = True
            continue
        gap = False
        is_punct = all(not c.isalnum() for c in piece)
        if cur is None or (new_word and not is_punct):
            if cur:
                out.append(cur)
            cur = {"w": piece, "s": round(offset_sec + t, 2), "e": round(offset_sec + t + 0.28, 2)}
        else:
            cur["w"] += piece
            cur["e"] = round(offset_sec + t + 0.20, 2)
    if cur:
        out.append(cur)

    # Sanitize bounds
    for i in range(len(out) - 1):
        out[i]["e"] = max(out[i]["s"] + 0.05, min(out[i]["e"], out[i + 1]["s"]))
    return out


def _transcribe_with_whisper(audio_input: Any, offset_sec: float = 0.0) -> List[Dict]:
    """
    Fallback transcription using the bundled local Faster-Whisper engine.
    Ensures 100% reliability on any machine without extra dependencies.
    """
    from app.transcriber import get_whisper_model

    model = get_whisper_model()

    if isinstance(audio_input, (str, Path)):
        audio_target = str(audio_input)
    elif isinstance(audio_input, np.ndarray):
        if audio_input.dtype == np.int16:
            audio_target = audio_input.astype(np.float32) / 32768.0
        else:
            audio_target = audio_input.astype(np.float32)
    elif isinstance(audio_input, (bytes, bytearray)):
        arr = np.frombuffer(audio_input, dtype=np.int16)
        audio_target = arr.astype(np.float32) / 32768.0
    else:
        raise ValueError(f"Unsupported audio input type for Whisper: {type(audio_input)}")

    segments, info = model.transcribe(
        audio_target,
        beam_size=3,
        word_timestamps=True,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=400),
    )

    words = []
    for seg in segments:
        if seg.words:
            for w in seg.words:
                clean_w = (w.word or "").strip()
                if clean_w:
                    words.append({
                        "w": clean_w,
                        "s": round(offset_sec + float(w.start), 2),
                        "e": round(offset_sec + float(w.end), 2),
                    })
    return words


def transcribe(audio_input: Any, offset_sec: float = 0.0) -> List[Dict]:
    """
    Transcribes audio into PeakCut format: [{'w': word, 's': start_sec, 'e': end_sec}, ...]
    Accepts: .wav file path, float32 ndarray, or int16 PCM bytes.
    If Sherpa-ONNX is not installed or model is unavailable, gracefully falls back to Faster-Whisper.
    """
    if not is_model_ready():
        return _transcribe_with_whisper(audio_input, offset_sec=offset_sec)

    try:
        rec = get_recognizer()

        if isinstance(audio_input, (str, Path)):
            p = Path(audio_input)
            try:
                with wave.open(str(p), "rb") as wf:
                    sr = wf.getframerate()
                    n_channels = wf.getnchannels()
                    frames = wf.readframes(wf.getnframes())
                    sampwidth = wf.getsampwidth()
                    if sampwidth == 2:
                        raw = np.frombuffer(frames, dtype=np.int16)
                        if n_channels > 1:
                            raw = raw.reshape(-1, n_channels).mean(axis=1)
                        samples = raw.astype(np.float32) / 32768.0
                    else:
                        samples = np.frombuffer(frames, dtype=np.float32)
            except Exception:
                cmd = [
                    config.FFMPEG_PATH or "ffmpeg",
                    "-y", "-v", "quiet",
                    "-i", str(p),
                    "-ac", "1", "-ar", "16000",
                    "-f", "s16le", "-"
                ]
                res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                raw = np.frombuffer(res.stdout, dtype=np.int16)
                samples = raw.astype(np.float32) / 32768.0
                sr = 16000
        elif isinstance(audio_input, np.ndarray):
            sr = 16000
            if audio_input.dtype == np.int16:
                samples = audio_input.astype(np.float32) / 32768.0
            else:
                samples = audio_input.astype(np.float32)
        elif isinstance(audio_input, (bytes, bytearray)):
            sr = 16000
            arr = np.frombuffer(audio_input, dtype=np.int16)
            samples = arr.astype(np.float32) / 32768.0
        else:
            raise ValueError("Unsupported audio format")

        total_sec = len(samples) / sr
        words = []

        if total_sec > 25.0:
            for a_idx, b_idx in _split_quiet_chunks(samples, lo=12.0, hi=24.0, sr=sr):
                seg = samples[a_idx:b_idx]
                if len(seg) < 4800 or float(np.sqrt((seg ** 2).mean())) < 0.003:
                    continue  # skip pure silence

                stream = rec.create_stream()
                stream.accept_waveform(sr, seg)
                rec.decode_stream(stream)

                toks = list(stream.result.tokens)
                stamps = [float(t) for t in stream.result.timestamps]
                seg_off = offset_sec + (a_idx / sr)
                words.extend(_tokens_to_words(toks, stamps, offset_sec=seg_off))
        else:
            stream = rec.create_stream()
            stream.accept_waveform(sr, samples)
            rec.decode_stream(stream)
            toks = list(stream.result.tokens)
            stamps = [float(t) for t in stream.result.timestamps]
            words = _tokens_to_words(toks, stamps, offset_sec=offset_sec)

        return words

    except Exception as e:
        # Graceful fallback to Faster-Whisper if Sherpa encounters runtime issues
        return _transcribe_with_whisper(audio_input, offset_sec=offset_sec)
