"""
In-App 1-Click Installer & Model Downloader for Parakeet-TDT 0.6B (Sherpa-ONNX).
Enables seamless offline ultra-fast transcription on any user PC.
"""
import os
import sys
import subprocess
import tarfile
import threading
import time
import urllib.request
from pathlib import Path
from typing import Dict, Any

from . import config

_lock = threading.Lock()
_state: Dict[str, Any] = {
    "is_installing": False,
    "progress": 0,
    "stage": "idle",  # idle | pip | downloading | extracting | completed | error
    "message": "",
    "error": None,
}

MODEL_ARCHIVE_URL = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
    "sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2"
)


def get_engine_status() -> Dict[str, Any]:
    with _lock:
        try:
            import sherpa_onnx  # noqa: F401
            has_lib = True
        except ImportError:
            has_lib = False

        model_dir = config.MODELS_DIR / config.MODEL_NAME
        has_model = False
        if model_dir.is_dir():
            enc = list(model_dir.glob("encoder*.onnx"))
            toks = model_dir / "tokens.txt"
            has_model = bool(enc and toks.is_file())

        return {
            "has_lib": has_lib,
            "has_model": has_model,
            "ready": has_lib and has_model,
            "is_installing": _state["is_installing"],
            "progress": _state["progress"],
            "stage": _state["stage"],
            "message": _state["message"],
            "error": _state["error"],
        }


def _run_installer():
    global _state
    try:
        # Step 1: Install sherpa-onnx if missing
        try:
            import sherpa_onnx  # noqa: F401
            has_lib = True
        except ImportError:
            has_lib = False

        if not has_lib:
            with _lock:
                _state.update({
                    "is_installing": True,
                    "progress": 10,
                    "stage": "pip",
                    "message": "Installing sherpa-onnx library via pip...",
                    "error": None,
                })

            cmd = [sys.executable, "-m", "pip", "install", "sherpa-onnx", "--no-warn-script-location"]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if res.returncode != 0:
                print(f"[!] pip install sherpa-onnx error: {res.stderr}")

        # Step 2: Check & download model files if missing
        model_dir = config.MODELS_DIR / config.MODEL_NAME
        has_model = False
        if model_dir.is_dir():
            enc = list(model_dir.glob("encoder*.onnx"))
            toks = model_dir / "tokens.txt"
            has_model = bool(enc and toks.is_file())

        if not has_model:
            with _lock:
                _state.update({
                    "is_installing": True,
                    "progress": 25,
                    "stage": "downloading",
                    "message": "Downloading Parakeet weights (460 MB compressed)...",
                    "error": None,
                })

            archive_path = config.MODELS_DIR / "parakeet_model.tar.bz2"
            req = urllib.request.Request(
                MODEL_ARCHIVE_URL,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
            )

            with urllib.request.urlopen(req, timeout=120) as resp, open(archive_path, "wb") as out_f:
                total_size = int(resp.headers.get("Content-Length") or 482440461)
                downloaded = 0
                chunk_size = 1024 * 512  # 512 KB
                last_time = time.time()

                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    out_f.write(chunk)
                    downloaded += len(chunk)
                    now = time.time()
                    if now - last_time > 0.5:
                        last_time = now
                        pct = min(85, int(25 + (downloaded / total_size) * 60))
                        mb_done = downloaded / (1024 * 1024)
                        mb_total = total_size / (1024 * 1024)
                        with _lock:
                            _state.update({
                                "progress": pct,
                                "message": f"Downloading Parakeet weights ({mb_done:.1f} MB / {mb_total:.1f} MB)...",
                            })

            with _lock:
                _state.update({
                    "progress": 88,
                    "stage": "extracting",
                    "message": "Extracting Parakeet model files into storage/models...",
                })

            with tarfile.open(archive_path, "r:bz2") as tar:
                tar.extractall(path=config.MODELS_DIR)

            archive_path.unlink(missing_ok=True)

        with _lock:
            _state.update({
                "is_installing": False,
                "progress": 100,
                "stage": "completed",
                "message": "Parakeet High-Speed Engine successfully installed & ready!",
                "error": None,
            })

    except Exception as e:
        with _lock:
            _state.update({
                "is_installing": False,
                "stage": "error",
                "message": f"Setup failed: {e}",
                "error": str(e),
            })


def start_install() -> Dict[str, Any]:
    with _lock:
        if _state["is_installing"]:
            return {"ok": False, "message": "Installation already in progress"}
        _state.update({
            "is_installing": True,
            "progress": 5,
            "stage": "starting",
            "message": "Starting Parakeet engine setup...",
            "error": None,
        })

    t = threading.Thread(target=_run_installer, daemon=True)
    t.start()
    return {"ok": True, "message": "Installation started in background"}
