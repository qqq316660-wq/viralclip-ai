import sys
import os
import json
import shutil
import time
from pathlib import Path

base = Path(r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI")
sys.path.insert(0, str(base / "backend"))

import app.config as config
config.BASE_DIR = base
config.STORAGE_DIR = base / "storage"
config.CLIPS_DIR = base / "storage" / "clips"
config.DOWNLOADS_DIR = base / "storage" / "downloads"
config.FFMPEG_PATH = str(base / "ffmpeg" / "ffmpeg.exe")
config.FFPROBE_PATH = str(base / "ffmpeg" / "ffprobe.exe")

from app.subtitles import generate_ass_subtitles
from app.composer import render_clip
from app.models import AspectRatio, FitMode

jobs_db_path = base / "storage" / "jobs_database.json"
int_db_path = base / "storage" / "jobs_internal_database.json"

jobs_db = json.load(open(jobs_db_path, encoding="utf-8"))
int_db = json.load(open(int_db_path, encoding="utf-8"))

# ==============================================================
# 1. Recover GTA 5 (job_50a45dc5d9) - Files already on disk
# ==============================================================
print("[*] Processing GTA 5 (job_50a45dc5d9)...")
gta_prefix = "50a45dc5d9"
gta_job = jobs_db.get("job_50a45dc5d9")
if gta_job and "clips" in gta_job:
    for clip in gta_job["clips"]:
        old_id = clip["id"]
        new_id = f"{gta_prefix}_{old_id}"
        clip["id"] = new_id
        
        # Copy mp4
        old_mp4 = config.CLIPS_DIR / f"{old_id}.mp4"
        new_mp4 = config.CLIPS_DIR / f"{new_id}.mp4"
        if old_mp4.exists() and not new_mp4.exists():
            shutil.copy2(old_mp4, new_mp4)
            
        # Copy branding & ass
        old_branding = config.CLIPS_DIR / f"{old_id}_branding.png"
        new_branding = config.CLIPS_DIR / f"{new_id}_branding.png"
        if old_branding.exists() and not new_branding.exists():
            shutil.copy2(old_branding, new_branding)
            
        old_ass = config.CLIPS_DIR / f"{old_id}_subtitles.ass"
        new_ass = config.CLIPS_DIR / f"{new_id}_subtitles.ass"
        if old_ass.exists() and not new_ass.exists():
            shutil.copy2(old_ass, new_ass)
            
        clip["rendered_url"] = f"/api/clips/{new_id}.mp4"
    print("  -> GTA 5 clips mapped to unique filenames successfully!")

# ==============================================================
# 2. Recover INDIA'S GOT LATENT (job_2797dcaf0d) - Render fresh
# ==============================================================
print("\n[*] Processing INDIA'S GOT LATENT (job_2797dcaf0d)...")
igl_job_id = "job_2797dcaf0d"
igl_prefix = "2797dcaf0d"
igl_int = int_db.get(igl_job_id)
igl_job = jobs_db.get(igl_job_id)

if igl_int and igl_job:
    video_path = Path(igl_int["video_path"])
    words = igl_int["transcription_result"].get("words", [])
    clips = igl_job["clips"]
    total = len(clips)
    
    for i, clip in enumerate(clips, 1):
        old_id = clip["id"]
        # Ensure clean id
        clean_name = old_id.split("_")[-1] if "custom_clip" in old_id else str(i)
        new_id = f"{igl_prefix}_custom_clip_{clean_name}"
        clip["id"] = new_id
        
        out_mp4 = config.CLIPS_DIR / f"{new_id}.mp4"
        out_sub = config.CLIPS_DIR / f"{new_id}_subtitles.ass"
        
        if not out_mp4.exists() or out_mp4.stat().st_size == 0:
            print(f"  Rendering [{i}/{total}]: {clip.get('title')} ({clip['start_time']}s - {clip['end_time']}s)...")
            generate_ass_subtitles(
                words=words,
                clip_start=clip["start_time"],
                clip_end=clip["end_time"],
                output_ass_path=out_sub,
                style="minimal"
            )
            render_clip(
                source_video_path=video_path,
                start_time=clip["start_time"],
                end_time=clip["end_time"],
                ass_subtitle_path=out_sub,
                output_clip_path=out_mp4,
                aspect_ratio=AspectRatio.PORTRAIT_9_16,
                fit_mode=FitMode.BLUR_PADDING
            )
        clip["rendered_url"] = f"/api/clips/{new_id}.mp4"
    print("  -> INDIA'S GOT LATENT clips recovered successfully!")

# ==============================================================
# 3. Recover job_918b3a97c5_raw (job_613fdbd38a) - Render fresh
# ==============================================================
print("\n[*] Processing job_918b3a97c5_raw (job_613fdbd38a)...")
raw_job_id = "job_613fdbd38a"
raw_prefix = "613fdbd38a"
raw_int = int_db.get(raw_job_id)
raw_job = jobs_db.get(raw_job_id)

if raw_int and raw_job:
    video_path = Path(raw_int["video_path"])
    words = raw_int["transcription_result"].get("words", [])
    clips = raw_job["clips"]
    total = len(clips)
    
    for i, clip in enumerate(clips, 1):
        old_id = clip["id"]
        clean_name = old_id.split("_")[-1] if "custom_clip" in old_id else str(i)
        new_id = f"{raw_prefix}_custom_clip_{clean_name}"
        clip["id"] = new_id
        
        out_mp4 = config.CLIPS_DIR / f"{new_id}.mp4"
        out_sub = config.CLIPS_DIR / f"{new_id}_subtitles.ass"
        
        if not out_mp4.exists() or out_mp4.stat().st_size == 0:
            print(f"  Rendering [{i}/{total}]: {clip.get('title')} ({clip['start_time']}s - {clip['end_time']}s)...")
            generate_ass_subtitles(
                words=words,
                clip_start=clip["start_time"],
                clip_end=clip["end_time"],
                output_ass_path=out_sub,
                style="minimal"
            )
            render_clip(
                source_video_path=video_path,
                start_time=clip["start_time"],
                end_time=clip["end_time"],
                ass_subtitle_path=out_sub,
                output_clip_path=out_mp4,
                aspect_ratio=AspectRatio.PORTRAIT_9_16,
                fit_mode=FitMode.BLUR_PADDING
            )
        clip["rendered_url"] = f"/api/clips/{new_id}.mp4"
    print("  -> job_918b3a97c5_raw clips recovered successfully!")

# Save updated jobs_database.json
with open(jobs_db_path, "w", encoding="utf-8") as f:
    json.dump(jobs_db, f, indent=2)

print("\n[SUCCESS] All jobs database updated with unique scoped filenames!")
