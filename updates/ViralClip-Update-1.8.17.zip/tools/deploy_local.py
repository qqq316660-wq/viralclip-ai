import shutil
import subprocess
import os
import time
from pathlib import Path

# 1. Kill any existing python on port 8001
try:
    out = subprocess.check_output(["netstat", "-ano", "-p", "tcp"], text=True)
    for line in out.splitlines():
        if ":8001" in line and "LISTENING" in line:
            parts = line.strip().split()
            pid = parts[-1]
            subprocess.run(["taskkill", "/F", "/PID", pid], capture_output=True)
            print(f"Killed old server PID: {pid}")
except Exception as e:
    print(f"Kill error: {e}")

time.sleep(1)

# 2. Copy updated backend files to installed app
dst_backend = Path(r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI\backend\app\stream_sniper")
dst_backend.mkdir(parents=True, exist_ok=True)
for fname in ["brain.py", "session.py", "media.py", "render.py", "router.py", "config.py"]:
    src = Path(f"backend/app/stream_sniper/{fname}")
    if src.exists():
        shutil.copyfile(src, dst_backend / fname)
        print(f"Copied {fname} to installed backend!")

# Also copy main.py
src_main = Path("backend/app/main.py")
dst_main = Path(r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI\backend\app\main.py")
if src_main.exists():
    shutil.copyfile(src_main, dst_main)
    print("Copied main.py to installed backend!")

# 3. Copy frontend dist to installed app web folder
src_dist = Path("frontend/dist")
dst_web = Path(r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI\web")
if src_dist.exists() and dst_web.exists():
    for item in src_dist.iterdir():
        dest = dst_web / item.name
        if item.is_dir():
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(item, dest)
        else:
            shutil.copy2(item, dest)
    print("Copied frontend/dist into installed app web directory!")

# 4. Start backend server
py_exec = r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI\python\python.exe"
srv_script = r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI\backend\run_server.py"
log_path = r"C:\Users\Akash\AppData\Local\Programs\ViralClip AI\backend\server.log"
with open(log_path, "a", encoding="utf-8") as log_file:
    subprocess.Popen(
        [py_exec, srv_script],
        cwd=str(Path(srv_script).parent),
        stdout=log_file,
        stderr=subprocess.STDOUT,
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    )
print("Server launch triggered on 8001!")
