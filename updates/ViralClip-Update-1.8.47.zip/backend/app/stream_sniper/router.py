"""FastAPI router for Stream Sniper (GTA 6 / Gaming Live & Chunked VOD Clipper)."""
import json
import logging
import re
import shutil
import subprocess
import time
import urllib.request
from pathlib import Path
from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from . import brain, config, session, media, facecam

logger = logging.getLogger(__name__)

router = APIRouter()


class StartLiveRequest(BaseModel):
    url: str
    style: Optional[str] = "bounce"
    layout: Optional[str] = "gameplay"
    enable_facecam: Optional[bool] = True


class ClipNowRequest(BaseModel):
    seconds: Optional[int] = 45


class KeysRequest(BaseModel):
    groq_key: Optional[str] = None
    gemini_key: Optional[str] = None
    openai_key: Optional[str] = None
    openrouter_key: Optional[str] = None


class TestKeyRequest(BaseModel):
    provider: str
    key: str


class PreviewFrameRequest(BaseModel):
    url: str
    timestamp_sec: Optional[float] = 600.0


class CancelChunkRequest(BaseModel):
    chunk_idx: int


class ReframeSettingsRequest(BaseModel):
    layout: Optional[str] = "splitscreen"
    facecam_box: Optional[List[float]] = None
    gameplay_box: Optional[List[float]] = None
    hook_y: Optional[float] = None
    cap_y: Optional[float] = None
    split_pct: Optional[int] = 35


class InitVODRequest(BaseModel):
    url: str
    chunk_minutes: Optional[int] = 30
    style: Optional[str] = "bounce"
    layout: Optional[str] = "splitscreen"
    enable_facecam: Optional[bool] = False
    facecam_box: Optional[List[float]] = None
    gameplay_box: Optional[List[float]] = None
    hook_y: Optional[float] = None
    cap_y: Optional[float] = None
    split_pct: Optional[int] = 35
    quality: Optional[int] = 720


class ProcessChunkRequest(BaseModel):
    chunk_idx: int
    transcriber: Optional[str] = "parakeet"  # "parakeet" | "kaggle"
    kaggle_url: Optional[str] = None
    ai_mode: Optional[Any] = "auto"          # "auto" | "prompt" | False | True
    style: Optional[str] = None
    layout: Optional[str] = None
    facecam_box: Optional[List[float]] = None
    gameplay_box: Optional[List[float]] = None
    hook_y: Optional[float] = None
    cap_y: Optional[float] = None
    split_pct: Optional[int] = None


class SubmitJSONRequest(BaseModel):
    chunk_idx: int
    json_data: str
    style: Optional[str] = None
    layout: Optional[str] = None


class MergeChunksRequest(BaseModel):
    indices: List[int]


class SubmitMergedJSONRequest(BaseModel):
    json_data: str
    style: Optional[str] = None
    layout: Optional[str] = None


class ResumeVODRequest(BaseModel):
    session_id: str


@router.get("/keys")
def get_keys():
    return {
        "groq": bool(config.GROQ_KEY),
        "gemini": bool(config.GEMINI_KEY),
        "openai": bool(config.OPENAI_KEY),
        "openrouter": bool(config.OPENROUTER_KEY),
        "groq_key": config.GROQ_KEY,
        "gemini_key": config.GEMINI_KEY,
        "openai_key": config.OPENAI_KEY,
        "openrouter_key": config.OPENROUTER_KEY,
        "groq_preview": (config.GROQ_KEY[:6] + "..." + config.GROQ_KEY[-4:]) if len(config.GROQ_KEY) > 10 else ("*" * len(config.GROQ_KEY)),
        "gemini_preview": (config.GEMINI_KEY[:6] + "..." + config.GEMINI_KEY[-4:]) if len(config.GEMINI_KEY) > 10 else ("*" * len(config.GEMINI_KEY)),
        "openai_preview": (config.OPENAI_KEY[:6] + "..." + config.OPENAI_KEY[-4:]) if len(config.OPENAI_KEY) > 10 else ("*" * len(config.OPENAI_KEY)),
        "openrouter_preview": (config.OPENROUTER_KEY[:6] + "..." + config.OPENROUTER_KEY[-4:]) if len(config.OPENROUTER_KEY) > 10 else ("*" * len(config.OPENROUTER_KEY)),
    }


@router.post("/keys")
def update_keys(req: KeysRequest):
    if req.groq_key is not None:
        config.GROQ_KEY = req.groq_key.strip()
    if req.gemini_key is not None:
        config.GEMINI_KEY = req.gemini_key.strip()
    if req.openai_key is not None:
        config.OPENAI_KEY = req.openai_key.strip()
    if req.openrouter_key is not None:
        config.OPENROUTER_KEY = req.openrouter_key.strip()
    config.save_keys()
    if session.VOD_SESSION:
        for c in session.VOD_SESSION.chunks:
            if c.get("ai_error"):
                c["ai_error"] = None
        session.save_vod_session_to_disk(session.VOD_SESSION)
    return {"status": "ok", "message": "API keys saved successfully"}


@router.post("/keys/test")
def test_key(req: TestKeyRequest):
    """Tests if an API key is valid by making a fast lightweight call."""
    from . import brain
    key_to_test = req.key
    if not key_to_test or not key_to_test.strip():
        p = (req.provider or "").lower().strip()
        if p == "gemini":
            key_to_test = config.GEMINI_KEY
        elif p == "groq":
            key_to_test = config.GROQ_KEY
        elif p == "openai":
            key_to_test = config.OPENAI_KEY
        elif p == "openrouter":
            key_to_test = config.OPENROUTER_KEY

    if not key_to_test or not key_to_test.strip():
        return {
            "ok": False,
            "provider": req.provider,
            "message": f"No {req.provider} key provided or saved."
        }

    ok, message = brain.test_api_key(req.provider, key_to_test)
    return {
        "ok": ok,
        "provider": req.provider,
        "message": message
    }


# ---------------------------------------------------------
# Live Pulse Sniper
# ---------------------------------------------------------

@router.post("/live/start")
def start_live(req: StartLiveRequest):
    if not req.url or not req.url.strip():
        raise HTTPException(status_code=400, detail="Stream URL is required")

    if session.LIVE_SESSION and not session.LIVE_SESSION.ended:
        session.LIVE_SESSION.stop()

    s = session.LiveSniperSession(
        url=req.url.strip(),
        style=req.style or "bounce",
        layout=req.layout or "gameplay",
        enable_facecam=req.enable_facecam if req.enable_facecam is not None else True
    )
    s.start()
    session.LIVE_SESSION = s
    return {"status": "started", "session_id": s.id}


@router.post("/live/stop")
def stop_live():
    if session.LIVE_SESSION:
        session.LIVE_SESSION.stop()
        return {"status": "stopped"}
    return {"status": "idle"}


@router.get("/live/status")
def get_live_status():
    s = session.LIVE_SESSION
    if not s:
        return {
            "active": False,
            "status": "idle",
            "db": [],
            "current_db": -100.0,
            "chat_velocity": 0,
            "title": "",
            "uploader": "",
            "game": ""
        }

    with s.lock:
        db_history = list(s.db[-35:])
        current_db = s.db[-1] if s.db else -100.0

    return {
        "active": not s.ended,
        "status": s.status,
        "error": s.error,
        "title": s.title,
        "uploader": s.uploader,
        "game": s.game,
        "db": db_history,
        "current_db": current_db,
        "chat_velocity": s.chat_velocity,
        "samples_sec": round(s.samples / session.SR, 1),
        "facecam_detected": bool(s.facecam_box)
    }


@router.post("/live/clip-now")
def clip_now(req: ClipNowRequest):
    s = session.LIVE_SESSION
    if not s or s.ended:
        raise HTTPException(status_code=400, detail="No active live stream recording.")

    sec = req.seconds or 45
    try:
        clip_info = s.clip_last(sec)
        return {"status": "queued", "clip": clip_info}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ---------------------------------------------------------
# Chunked Deep VOD Scanner
# ---------------------------------------------------------
# Stream Reframe & Layout Preview Endpoints
# ---------------------------------------------------------

@router.post("/vod/preview-frame")
def get_preview_frame(req: PreviewFrameRequest):
    """Fetches real gameplay/facecam snapshot directly from the video stream for split screen reframing.
    Extracts the actual real stream frame at the exact requested timestamp (e.g. 35m / 2100s).
    """
    url = req.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="Stream URL is required")

    out_dir = config.STORAGE_DIR / "stream_sniper" / "previews"
    out_dir.mkdir(parents=True, exist_ok=True)

    m = re.search(r"(?:v=|\/live\/|youtu\.be\/|\/shorts\/)([a-zA-Z0-9_-]{11})", url)
    vid = m.group(1) if m else "preview"
    ts = max(5.0, float(req.timestamp_sec or 2100.0))
    ts_tag = int(ts)
    frame_file = out_dir / f"{vid}_frame_{ts_tag}.jpg"

    # 1. If real stream frame already exists locally and is valid, return immediately
    if frame_file.exists() and frame_file.stat().st_size > 2000:
        meta = {}
        try:
            meta = media.probe(frame_file)
        except Exception:
            pass
        detected_fc = None
        try:
            fc_res = facecam.detect_facecam(frame_file, streamer_hint=vid)
            if fc_res and (fc_res.get("found") or fc_res.get("box")):
                detected_fc = fc_res["box"]
        except Exception:
            pass
        return {
            "ok": True,
            "frame_url": f"/api/sniper/vod/preview-image/{frame_file.name}?t={int(time.time() * 1000)}",
            "width": meta.get("width", 1280),
            "height": meta.get("height", 720),
            "timestamp_sec": ts,
            "detected_facecam": detected_fc
        }

    # Clean old frame to guarantee fresh real stream capture
    frame_file.unlink(missing_ok=True)

    # 2. Check if a downloaded chunk video already exists locally in storage
    local_candidates = list((config.STORAGE_DIR / "stream_sniper" / "chunks").glob(f"*{vid}*.mp4")) + \
                       list((config.STORAGE_DIR / "stream_sniper" / "buffer").glob(f"*{vid}*.mp4"))
    for lcand in local_candidates:
        if lcand.exists() and lcand.stat().st_size > 500000:
            try:
                cmd = [config.FFMPEG_PATH, "-y", "-ss", "00:00:15", "-i", str(lcand), "-frames:v", "1", "-q:v", "2", str(frame_file)]
                subprocess.run(cmd, capture_output=True, timeout=5, creationflags=config.NO_WINDOW)
                if frame_file.exists() and frame_file.stat().st_size > 2000:
                    break
            except Exception:
                pass

    # 3. Extract the REAL stream frame at exact target timestamp (ts) using HLS H.264 seek (unthrottled)
    if not frame_file.exists() or frame_file.stat().st_size < 2000:
        stream_url = None
        http_headers = {}
        target_ts = ts
        try:
            # Strictly prioritize H.264 (avc1) itags 230/231/229/311 or mp4 HLS (prevents slow VP9 header parsing)
            fmt_choice = "230/231/229/311/bv*[protocol=m3u8_native][vcodec^=avc1][height<=480]/18/134/worst[ext=mp4]/bestvideo[height<=480]/best[height<=480]"
            with media._ydl({"format": fmt_choice, "extract_flat": False}) as ydl:
                info = ydl.extract_info(url, download=False)
                dur = float(info.get("duration") or 0.0)
                if dur > 10.0 and ts >= dur:
                    target_ts = max(5.0, dur * 0.5)
                stream_url = info.get("url")
                if not stream_url and info.get("requested_formats"):
                    stream_url = info["requested_formats"][0].get("url")
                http_headers = info.get("http_headers", {})

            if stream_url:
                user_agent = http_headers.get("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                headers_opt = f"User-Agent: {user_agent}\r\n"
                ff_cmd = [
                    config.FFMPEG_PATH, "-y",
                    "-headers", headers_opt,
                    "-reconnect", "1",
                    "-reconnect_streamed", "1",
                    "-reconnect_delay_max", "5",
                    "-ss", str(target_ts),
                    "-i", stream_url,
                    "-frames:v", "1",
                    "-q:v", "2",
                    str(frame_file)
                ]
                subprocess.run(ff_cmd, capture_output=True, timeout=25, creationflags=config.NO_WINDOW)
        except Exception as e:
            logger.warning(f"Real stream frame seek failed at {ts}s: {e}")

        # If seeking at target_ts failed, fallback to 15s of the real stream
        if (not frame_file.exists() or frame_file.stat().st_size < 2000) and stream_url:
            try:
                user_agent = http_headers.get("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                ff_fallback = [
                    config.FFMPEG_PATH, "-y",
                    "-headers", f"User-Agent: {user_agent}\r\n",
                    "-reconnect", "1",
                    "-reconnect_streamed", "1",
                    "-reconnect_delay_max", "5",
                    "-ss", "15.0",
                    "-i", stream_url,
                    "-frames:v", "1",
                    "-q:v", "2",
                    str(frame_file)
                ]
                subprocess.run(ff_fallback, capture_output=True, timeout=15, creationflags=config.NO_WINDOW)
            except Exception as fe:
                logger.warning(f"Real stream frame fallback seek failed: {fe}")

    # 4. Fallback: Native yt-dlp 2-second real stream slice download (100% REAL gameplay footage, no thumbnail)
    if not frame_file.exists() or frame_file.stat().st_size < 2000:
        try:
            slice_stem = f"{vid}_temp_preview_slice"
            slice_path = media.download_section(url, out_dir, slice_stem, max(0.0, target_ts), target_ts + 2.0, height=360)
            if slice_path and slice_path.exists() and slice_path.stat().st_size > 5000:
                cmd = [
                    config.FFMPEG_PATH, "-y",
                    "-ss", "00:00:00.5",
                    "-i", str(slice_path),
                    "-frames:v", "1",
                    "-q:v", "2",
                    str(frame_file)
                ]
                subprocess.run(cmd, capture_output=True, timeout=10, creationflags=config.NO_WINDOW)
                try:
                    slice_path.unlink(missing_ok=True)
                except Exception:
                    pass
        except Exception as se:
            logger.warning(f"Real stream slice fallback failed: {se}")

    # 5. Ultimate Fallback: Dark studio canvas with streamer & gameplay guides (so UI never breaks)
    if not frame_file.exists() or frame_file.stat().st_size < 1000:
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (1280, 720), color=(18, 20, 26))
            draw = ImageDraw.Draw(img)
            draw.rectangle([0, 0, 1280, 720], outline=(0, 240, 255), width=2)
            draw.rectangle([20, 20, 360, 220], fill=(28, 32, 42), outline=(255, 68, 68), width=3)
            draw.text((40, 40), "STREAMER FACECAM ZONE", fill=(255, 100, 100))
            draw.rectangle([280, 100, 1000, 680], fill=(24, 28, 36), outline=(0, 240, 255), width=2)
            draw.text((500, 340), f"GAMEPLAY FOCUS ({vid})", fill=(0, 240, 255))
            draw.text((520, 380), f"Timestamp: {int(ts//60)}m ({int(ts)}s)", fill=(160, 160, 160))
            frame_file.parent.mkdir(parents=True, exist_ok=True)
            img.save(frame_file, "JPEG", quality=90)
        except Exception as pe:
            logger.error(f"Canvas generation fallback failed: {pe}")

    # Process and return response with AI Facecam YuNet coordinates
    meta = {}
    try:
        meta = media.probe(frame_file)
    except Exception:
        pass
    detected_fc = None
    try:
        fc_res = facecam.detect_facecam(frame_file, streamer_hint=vid)
        if fc_res and (fc_res.get("found") or fc_res.get("box")):
            detected_fc = fc_res["box"]
    except Exception as fe:
        logger.warning(f"Facecam YuNet auto-detect failed: {fe}")

    return {
        "ok": True,
        "frame_url": f"/api/sniper/vod/preview-image/{frame_file.name}?t={int(time.time() * 1000)}",
        "width": meta.get("width", 1280),
        "height": meta.get("height", 720),
        "timestamp_sec": ts,
        "detected_facecam": detected_fc
    }


@router.post("/vod/cancel-chunk")
def cancel_vod_chunk(req: CancelChunkRequest):
    """Cancels a currently processing or transcribing chunk and resets its status."""
    v = session.VOD_SESSION
    if not v:
        saved = session.list_saved_vod_sessions()
        if saved:
            v = session.restore_vod_session_from_disk(saved[0]["id"])
    if not v:
        raise HTTPException(status_code=400, detail="No active stream session")
    v.cancel_chunk(req.chunk_idx)
    return {"ok": True, "chunk_idx": req.chunk_idx, "status": "cancelled"}


@router.get("/vod/preview-image/{filename}")
def serve_preview_image(filename: str):
    p = config.STORAGE_DIR / "stream_sniper" / "previews" / filename
    if not p.exists() or p.stat().st_size < 100:
        try:
            from PIL import Image, ImageDraw
            p.parent.mkdir(parents=True, exist_ok=True)
            img = Image.new("RGB", (1280, 720), color=(18, 20, 26))
            draw = ImageDraw.Draw(img)
            draw.rectangle([0, 0, 1280, 720], outline=(0, 240, 255), width=2)
            draw.rectangle([20, 20, 360, 220], fill=(28, 32, 42), outline=(255, 68, 68), width=3)
            draw.rectangle([280, 100, 1000, 680], fill=(24, 28, 36), outline=(0, 240, 255), width=2)
            img.save(p, "JPEG", quality=90)
        except Exception:
            raise HTTPException(status_code=404, detail="Image not found")
    media_type = "image/jpeg"
    if p.suffix.lower() == ".png":
        media_type = "image/png"
    elif p.suffix.lower() == ".webp":
        media_type = "image/webp"
    return FileResponse(
        p,
        media_type=media_type,
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )


class DetectFacecamRequest(BaseModel):
    image_name: Optional[str] = None
    stream_url: Optional[str] = None


@router.post("/vod/detect-facecam")
def api_detect_facecam(req: DetectFacecamRequest):
    """Detects streamer facecam in a preview frame using local YuNet AI."""
    preview_dir = config.STORAGE_DIR / "stream_sniper" / "previews"
    target_img = None
    if req.image_name:
        p = preview_dir / Path(req.image_name).name
        if p.exists():
            target_img = p
    if not target_img:
        imgs = sorted(list(preview_dir.glob("*.jpg")) + list(preview_dir.glob("*.png")), key=lambda f: f.stat().st_mtime, reverse=True)
        if imgs:
            target_img = imgs[0]

    if not target_img:
        raise HTTPException(status_code=404, detail="No preview image found to detect facecam.")

    res = facecam.detect_facecam(target_img, streamer_hint=req.stream_url)
    return res


@router.post("/vod/save-reframe")
def save_reframe(req: ReframeSettingsRequest):
    v = session.VOD_SESSION
    if not v:
        saved = session.list_saved_vod_sessions()
        if saved:
            v = session.restore_vod_session_from_disk(saved[0]["id"])
    if not v:
        raise HTTPException(status_code=400, detail="No active VOD session")

    if req.layout:
        v.layout = req.layout
    if req.facecam_box:
        v.facecam_box = req.facecam_box
    if req.gameplay_box:
        v.gameplay_box = req.gameplay_box
    if req.hook_y is not None:
        v.hook_y = req.hook_y
    if req.cap_y is not None:
        v.cap_y = req.cap_y
    if req.split_pct is not None:
        v.split_pct = req.split_pct

    v.reframe_locked = True
    session.save_vod_session_to_disk(v)
    return {
        "ok": True,
        "layout": v.layout,
        "facecam_box": v.facecam_box,
        "gameplay_box": v.gameplay_box,
        "hook_y": v.hook_y,
        "cap_y": v.cap_y,
        "split_pct": v.split_pct,
        "reframe_locked": True
    }


# ---------------------------------------------------------
# VOD Scanner Endpoints
# ---------------------------------------------------------

@router.post("/vod/clean-cache")
def clean_cache():
    """Purges all temporary raw audio/video slices, .part files, and work dirs while keeping finished clips."""
    freed_bytes = session.purge_all_temp_cache()
    freed_mb = round(freed_bytes / (1024 * 1024), 1)
    return {
        "ok": True,
        "freed_bytes": freed_bytes,
        "freed_mb": freed_mb,
        "message": f"Successfully freed {freed_mb} MB of temporary disk space!"
    }


@router.post("/vod/init")
def init_vod(req: InitVODRequest):
    if not req.url or not req.url.strip():
        raise HTTPException(status_code=400, detail="Stream URL is required")

    # Clean old leftover temporary files to prevent hard drive from clogging
    session.purge_all_temp_cache()

    session._SESSION_EXPLICITLY_RESET = False
    v = session.VODSniperSession(
        url=req.url.strip(),
        style=req.style or "bounce",
        layout=req.layout or "splitscreen",
        enable_facecam=req.enable_facecam if req.enable_facecam is not None else False,
        chunk_minutes=req.chunk_minutes or 30,
        facecam_box=req.facecam_box,
        gameplay_box=req.gameplay_box,
        hook_y=req.hook_y,
        cap_y=req.cap_y,
        split_pct=req.split_pct or 35,
        quality=req.quality or 720
    )
    if req.facecam_box:
        v.reframe_locked = True
    try:
        v.init_stream()
        session.VOD_SESSION = v
        return {
            "status": "initialized",
            "session_id": v.id,
            "title": v.title,
            "uploader": v.uploader,
            "duration": v.duration,
            "game": v.game,
            "chunk_minutes": v.chunk_minutes,
            "chunks": v.chunks
        }
    except Exception as e:
        clean_err = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]?", "", str(e)).strip()
        raise HTTPException(status_code=400, detail=f"Failed to analyze stream: {clean_err}")


@router.post("/vod/process-chunk")
def process_chunk(req: ProcessChunkRequest, background_tasks: BackgroundTasks):
    v = session.VOD_SESSION
    if not v:
        raise HTTPException(status_code=400, detail="Initialize VOD session first.")

    if req.style:
        v.style = req.style
    if req.layout:
        v.layout = req.layout
    # Only update framing if reframe is NOT yet locked for this stream
    if not getattr(v, "reframe_locked", False):
        if req.facecam_box:
            v.facecam_box = req.facecam_box
        if req.gameplay_box:
            v.gameplay_box = req.gameplay_box
        if req.hook_y is not None:
            v.hook_y = req.hook_y
        if req.cap_y is not None:
            v.cap_y = req.cap_y
        if req.split_pct is not None:
            v.split_pct = req.split_pct

    result = v.enqueue_chunk(
        req.chunk_idx,
        req.transcriber or "parakeet",
        req.kaggle_url,
        req.ai_mode or "auto"
    )
    return result


@router.get("/vod/status")
def get_vod_status():
    v = session.VOD_SESSION
    if not v and not getattr(session, "_SESSION_EXPLICITLY_RESET", False):
        saved = session.list_saved_vod_sessions()
        if saved:
            v = session.restore_vod_session_from_disk(saved[0]["id"])
            session.VOD_SESSION = v
    if not v:
        return {
            "status": "idle",
            "url": "",
            "progress": 0,
            "stage": "",
            "title": "",
            "uploader": "",
            "game": "",
            "chunks": []
        }
    return {
        "status": v.status,
        "url": getattr(v, "url", ""),
        "stage": v.stage,
        "progress": v.progress,
        "title": v.title,
        "uploader": v.uploader,
        "game": v.game,
        "error": v.error,
        "active_chunk_idx": v.active_chunk_idx,
        "chunk_queue": [q["chunk_idx"] for q in getattr(v, "chunk_queue", [])],
        "render_queue": [q["chunk_idx"] for q in getattr(v, "render_queue", [])],
        "active_render_chunk_idx": getattr(v, "active_render_chunk_idx", None),
        "chunks": v.chunks,
        "clips_count": len(v.clips),
        "merged_ready": bool(v.merged_transcript),
        "layout": getattr(v, "layout", "splitscreen"),
        "style": getattr(v, "style", "bounce"),
        "facecam_box": getattr(v, "facecam_box", None),
        "gameplay_box": getattr(v, "gameplay_box", None),
        "hook_y": getattr(v, "hook_y", 672),
        "cap_y": getattr(v, "cap_y", 1728),
        "split_pct": getattr(v, "split_pct", 35),
        "reframe_locked": getattr(v, "reframe_locked", False)
    }


@router.post("/vod/reset")
def reset_vod_session():
    """Wipes active in-memory VOD session so user can load a fresh stream."""
    session.VOD_SESSION = None
    session._SESSION_EXPLICITLY_RESET = True
    return {"ok": True, "status": "reset"}


@router.get("/vod/prompt/{chunk_idx}")
def get_chunk_prompt(chunk_idx: int):
    v = session.VOD_SESSION
    if not v or chunk_idx < 0 or chunk_idx >= len(v.chunks):
        raise HTTPException(status_code=404, detail="Chunk not found")

    chunk = v.chunks[chunk_idx]
    if not chunk.get("prompt"):
        raise HTTPException(status_code=400, detail="Chunk has not been transcribed yet.")

    return {
        "chunk_idx": chunk_idx,
        "label": chunk["label"],
        "prompt": chunk["prompt"]
    }


@router.post("/vod/submit-json")
def submit_chunk_json(req: SubmitJSONRequest, background_tasks: BackgroundTasks):
    v = session.VOD_SESSION
    if not v:
        raise HTTPException(status_code=400, detail="No active VOD session.")

    try:
        # Validate JSON upfront
        parsed = session.parse_clips_json(req.json_data)
        if not parsed:
            raise HTTPException(status_code=400, detail="No valid clip timestamps found in JSON.")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON format: {e}")

    if 0 <= req.chunk_idx < len(v.chunks):
        v.chunks[req.chunk_idx]["status"] = "processing"
    v.status = "processing"
    v.stage = f"Rendering {len(parsed)} shorts for {v.chunks[req.chunk_idx]['label']}..."
    v.active_chunk_idx = req.chunk_idx
    session.save_vod_session_to_disk(v)

    background_tasks.add_task(v.submit_json_for_chunk, req.chunk_idx, req.json_data, req.style, req.layout)
    return {"status": "queued", "clips_count": len(parsed)}


class AutoAnalyzeChunkRequest(BaseModel):
    chunk_idx: int


@router.post("/vod/auto-analyze-chunk")
def auto_analyze_chunk(req: AutoAnalyzeChunkRequest, background_tasks: BackgroundTasks):
    v = session.VOD_SESSION
    if not v:
        raise HTTPException(status_code=400, detail="No active VOD session.")
    if req.chunk_idx < 0 or req.chunk_idx >= len(v.chunks):
        raise HTTPException(status_code=400, detail="Invalid chunk index.")

    background_tasks.add_task(v.process_chunk_ai_direct, req.chunk_idx)
    return {"status": "started", "chunk_idx": req.chunk_idx}


class RetryRenderChunkRequest(BaseModel):
    chunk_idx: int


@router.post("/vod/retry-render-chunk")
def retry_render_chunk(req: RetryRenderChunkRequest, background_tasks: BackgroundTasks):
    """Retries rendering viral clips for an errored chunk without re-transcribing or re-running AI."""
    v = session.VOD_SESSION
    if not v:
        raise HTTPException(status_code=400, detail="No active VOD session.")
    if req.chunk_idx < 0 or req.chunk_idx >= len(v.chunks):
        raise HTTPException(status_code=400, detail="Invalid chunk index.")

    chunk = v.chunks[req.chunk_idx]
    clips_list = chunk.get("render_clips") or chunk.get("clips") or []
    if not clips_list:
        raise HTTPException(status_code=400, detail="No viral clips found to render for this chunk.")

    # Clear cancel flag and errors
    v._cancelled_chunks = getattr(v, "_cancelled_chunks", set())
    if req.chunk_idx in v._cancelled_chunks:
        v._cancelled_chunks.remove(req.chunk_idx)

    chunk["status"] = "processing"
    chunk["error"] = None
    chunk["diagnosis"] = None
    chunk["needs_cookies"] = False
    v.status = "processing"
    v.stage = f"Retrying render for {chunk.get('label', f'Chunk {req.chunk_idx+1}')} ({len(clips_list)} shorts)..."
    session.save_vod_session_to_disk(v)

    v.enqueue_chunk_render(req.chunk_idx, clips_list, source="retry")
    return {"status": "queued", "chunk_idx": req.chunk_idx, "clips_count": len(clips_list)}


@router.post("/vod/merge")
def merge_chunks(req: MergeChunksRequest):
    v = session.VOD_SESSION
    if not v:
        raise HTTPException(status_code=400, detail="No active VOD session.")

    try:
        merged_prompt = v.merge_chunks(req.indices)
        return {
            "status": "merged",
            "label": v.merged_transcript.get("label"),
            "prompt": merged_prompt
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/vod/submit-merged-json")
def submit_merged_json(req: SubmitMergedJSONRequest, background_tasks: BackgroundTasks):
    v = session.VOD_SESSION
    if not v or not v.merged_transcript:
        raise HTTPException(status_code=400, detail="No merged transcript found.")

    try:
        parsed = session.parse_clips_json(req.json_data)
        if not parsed:
            raise HTTPException(status_code=400, detail="No valid clips found in JSON.")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}")

    # Use first index of merged transcript
    first_idx = v.merged_transcript["indices"][0]
    background_tasks.add_task(v.submit_json_for_chunk, first_idx, req.json_data, req.style, req.layout)
    return {"status": "queued", "clips_count": len(parsed)}


@router.get("/vod/history")
def get_vod_history():
    """Returns saved VOD scanner sessions from disk."""
    return {"sessions": session.list_saved_vod_sessions()}


@router.post("/vod/history/resume")
def resume_vod_session(req: ResumeVODRequest):
    """Restores a saved VOD session into active memory with zero re-downloading."""
    sess = session.restore_vod_session_from_disk(req.session_id)
    if not sess:
        raise HTTPException(status_code=404, detail="Saved VOD session not found.")
    return {
        "status": "ready",
        "session_id": sess.id,
        "url": sess.url,
        "title": sess.title,
        "uploader": sess.uploader,
        "duration": sess.duration,
        "game": sess.game,
        "chunk_minutes": sess.chunk_minutes,
        "chunks": sess.chunks,
        "stage": sess.stage,
        "progress": sess.progress,
        "error": sess.error,
        "active_chunk_idx": sess.active_chunk_idx,
        "clips_count": len(sess.clips),
        "merged_ready": bool(sess.merged_transcript)
    }


@router.delete("/vod/history/{session_id}")
def delete_vod_history(session_id: str):
    """Deletes a saved session from storage history."""
    session.delete_saved_vod_session(session_id)
    return {"status": "deleted", "session_id": session_id}


@router.get("/clips")
def get_clips():
    clips = session.get_clips_registry()
    return {"clips": clips}


@router.delete("/clips/{clip_id}")
def delete_clip(clip_id: str):
    """Deletes a single rendered short from the gallery and disk."""
    success = session.delete_clip_from_registry(clip_id)
    return {"status": "deleted", "clip_id": clip_id, "success": success}


@router.delete("/clips")
def clear_clips(filter: Optional[str] = "all"):
    """Clears clips from gallery (filter: 'vod', 'live', or 'all')."""
    count = session.clear_clips_registry(filter or "all")
    return {"status": "cleared", "deleted_count": count, "filter": filter}


@router.get("/engine/parakeet-status")
def get_parakeet_engine_status():
    from . import parakeet_installer
    return parakeet_installer.get_engine_status()


@router.post("/engine/install-parakeet")
def install_parakeet_engine():
    from . import parakeet_installer
    return parakeet_installer.start_install()

